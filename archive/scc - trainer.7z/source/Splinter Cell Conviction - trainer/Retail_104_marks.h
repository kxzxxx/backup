/*
Conviction_game.exe+374288 - F6 81 C0000000 20     - test byte ptr [ecx+000000C0],20
Conviction_game.exe+37428F - 75 07                 - jne Conviction_game.exe+374298


===>
Conviction_game.exe+374291 - 33 C0                 - xor eax,eax
Conviction_game.exe+374293 - 39 41 5C              - cmp [ecx+5C],eax
===>


Conviction_game.exe+374296 - 7E 03                 - jle Conviction_game.exe+37429B
Conviction_game.exe+374298 - 33 C0                 - xor eax,eax
Conviction_game.exe+37429A - 40                    - inc eax
*/


static int marks_call = 0x374291;
static int marks_retn = 0x374296;



static void __declspec(naked) marks_asm()
{
	__asm
	{
		// check active
		cmp ini_marks_flag, 0
		je done



		// always on
		cmp ini_marks, 1
		jne marks_2

		mov [ecx + 0x5c], 1
		jmp done




marks_2:
		// always off
		cmp ini_marks, -1
		jne done

		mov [ecx + 0x5c], 0


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


done:
		// OLD code
		xor eax,eax
		cmp [ecx + 0x5C], eax



		push marks_retn
		ret
	}
}




// ################################################ //
// ################################################ //
// ################################################ //
// ################################################ //



static void Hook_Marks()
{
	if(1)
	{
		marks_retn = AddBase( marks_retn );



		HookMemory( AddBase(marks_call), marks_retn, (UINT) &marks_asm );
	}
}
