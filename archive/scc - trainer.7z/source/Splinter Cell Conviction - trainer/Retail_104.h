extern void Inject_Retail_104();
