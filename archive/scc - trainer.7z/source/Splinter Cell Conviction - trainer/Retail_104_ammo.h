
#if 0
/*
Conviction_game.exe+13E2A4 - 8D 8E 30080000        - lea ecx,[esi+00000830]
Conviction_game.exe+13E2AA - 8B 01                 - mov eax,[ecx]


===>
Conviction_game.exe+13E2AC - 3B D0                 - cmp edx,eax
Conviction_game.exe+13E2AE - 7F 08                 - jg Conviction_game.exe+13E2B8
Conviction_game.exe+13E2B0 - 2B C2                 - sub eax,edx
===>


Conviction_game.exe+13E2B2 - 89 01                 - mov [ecx],eax
Conviction_game.exe+13E2B4 - 8B C2                 - mov eax,edx
Conviction_game.exe+13E2B6 - 5E                    - pop esi
Conviction_game.exe+13E2B7 - C3                    - ret 
*/


static int ammo_call = 0x13e2ac;
static int ammo_retn = 0x13e2b2;



static void __declspec(naked) ammo_asm()
{
	__asm
	{
		// OLD code
		sub eax, edx


		cmp eax, 0
		jg done


		mov eax, 0


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


		cmp ini_refill_ammo, 0
		je done


		mov eax, ini_refill_ammo


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


done:
		push ammo_retn
		ret
	}
}
#else

/*
===>
Conviction_game.exe+13F6C4 - FF 8B 2C080000        - dec [ebx+0000082C]
===>


Conviction_game.exe+13F6CA - 85 7E 68              - test [esi+68],edi
Conviction_game.exe+13F6CD - 74 17                 - je Conviction_game.exe+13F6E6
Conviction_game.exe+13F6CF - 8B 83 54080000        - mov eax,[ebx+00000854]
Conviction_game.exe+13F6D5 - B9 00200000           - mov ecx,00002000
*/


static int ammo_call = 0x13f6c4;
static int ammo_retn = 0x13f6ca;



static void __declspec(naked) ammo_asm()
{
	__asm
	{
		// OLD code
		dec [ebx + 0x82C]


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


		push eax

			
		cmp ini_refill_ammo, 0
		je done


		mov eax, [ebx + 0x82c]
		add eax, [ebx + 0x830]
		cmp eax, 0
		jg done


		mov eax, ini_refill_ammo
		mov [ebx + 0x830], eax


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


done:
		pop eax



		push ammo_retn
		ret
	}
}
#endif




// ################################################ //
// ################################################ //
// ################################################ //
// ################################################ //



static void Hook_Ammo()
{
	if(1)
	{
		ammo_retn = AddBase( ammo_retn );



		HookMemory( AddBase(ammo_call), ammo_retn, (UINT) &ammo_asm );
	}
}
