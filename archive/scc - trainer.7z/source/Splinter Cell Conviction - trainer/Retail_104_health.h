#if 1

/*
===>
Conviction_game.exe+CF83E - F3 0F10 46 50         - movss xmm0,[esi+50]
===>


Conviction_game.exe+CF843 - F3 0F2A 56 60         - cvtsi2ss xmm2,[esi+60]
Conviction_game.exe+CF848 - F3 0F5C C1            - subss xmm0,xmm1
Conviction_game.exe+CF84C - 0F2F D0               - comiss xmm2,xmm0
Conviction_game.exe+CF84F - 72 06                 - jb Conviction_game.exe+CF857
*/


static int health_call = 0xcf83e;
static int health_retn = 0xcf843;




static float __stdcall health_code( BYTE *addr, float damage )
{
	DWORD id = *( (DWORD *) ( addr + 0x00 ) );
	float health = *( (float *) ( addr + 0x50 ) );



	if( damage < 0 ) return damage;




	// player
	if( id == 0xf5654c )
	{
		damage *= ini_player_damage;



		// no death
		if( ini_health && ( damage >= health ) )
			damage = health < 1.0f ? 0.0f : health - 1.0f;
	}


	// enemy
	else
	{
		// ignore execution kill
		if( damage < 100000.0f )
			damage *= ini_enemy_damage;


		// ignore all kill - melee combat only
		if( ini_enemy_damage == -1.0f )
			damage = 0.0f;
	}


	return damage;
}




static void __declspec(naked) health_asm()
{
	__asm
	{
		// 32+4 bytes
		pushad
		pushfd


		// args
		push eax
		movss [esp], xmm1


		push esi

		call health_code



		// new damage
		push eax
		fstp [esp]
		movss xmm1, [esp]
		pop eax


		popfd
		popad


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


		// OLD code
		movss xmm0, [esi + 0x50]



		push health_retn
		ret
	}
}



#else

/*
Conviction_game.exe+CF88D - F3 0F5C C1            - subss xmm0,xmm1


===>
Conviction_game.exe+CF891 - F3 0F11 46 50         - movss [esi+50],xmm0
===>


Conviction_game.exe+CF896 - 0F57 C0               - xorps xmm0,xmm0
Conviction_game.exe+CF899 - 0F2F 46 50            - comiss xmm0,[esi+50]
Conviction_game.exe+CF89D - F3 0F11 4E 4C         - movss [esi+4C],xmm1
Conviction_game.exe+CF8A2 - 72 1B                 - jb Conviction_game.exe+CF8BF
*/


static int health_call = 0xcf891;
static int health_retn = 0xcf896;




static void __stdcall health_code( BYTE *addr, float old_value )
{
	DWORD id = *( (DWORD *) ( addr + 0x00 ) );
	float *value = (float *) ( addr + 0x50 );
	float diff;



	diff = old_value - (*value);

	if( diff < 0 ) return;




	// player
	if( id == 0xf5654c )
	{
		diff *= ini_player_damage;



		// dead = ~20% @ 0.25
		if( (*value) == 0.0f && old_value < 200.0f )
			(*value) = 0.0f;

		// 1000.0f = full
		else
			(*value) = old_value + diff;



		// no death
		if( ini_health && ( (*value) <= 0.0f ) )
			(*value) = 1.0f;
	}


	// enemy
	else
	{
		// 1000.0f = allow head shot
		if( diff <= 1000.0f )
		{
			diff *= ini_enemy_damage;
			(*value) = old_value + diff;
		}
	}
}




static void __declspec(naked) health_asm()
{
	__asm
	{


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


		// 32+4 bytes
		pushad
		pushfd



		// old health
		mov eax, [esi + 0x50]


		// OLD code
		movss [esi + 0x50], xmm0



		// args
		push eax
		push esi

		call health_code



		popfd
		popad


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


		push health_retn
		ret
	}
}


#endif


// ################################################ //
// ################################################ //
// ################################################ //
// ################################################ //



static void Hook_Health()
{
	if(1)
	{
		health_retn = AddBase( health_retn );



		HookMemory( AddBase(health_call), health_retn, (UINT) &health_asm );
	}
}
