#include <stdio.h>
#include <string.h>


static char line[1024];



int ini_health;

float ini_player_damage;
float ini_enemy_damage;

int ini_refill_gadgets;
int ini_refill_ammo;

int ini_add_pec;
int ini_add_pec_flag;

int ini_marks;
int ini_marks_flag;




// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



void ReadIni()
{
	FILE *fp;


	fp = fopen( "scripts\\Trainer.ini", "r" );
	if( !fp )
	{
		fp = fopen( "scripts_asi\\Trainer.ini", "r" );
		if( !fp ) return;
	}



	while(1)
	{
		if( feof(fp) ) break;


		fgets( line, 1024, fp );



#define CHECK_ARG_STR(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%s", &y ); \
		continue; \
	}



#define CHECK_ARG(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%d", &y ); \
		continue; \
	}



#define CHECK_ARG_F(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%f", &y ); \
		continue; \
	}



#define CHECK_ARG_F_100(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%f", &temp_f ); \
		temp_f = temp_f * 100.0f; \
		y = (int) temp_f; \
		continue; \
	}




		float temp_f;



		//CHECK_ARG( "debug log =", ini_debug_log );


		CHECK_ARG( "prevent death =", ini_health );
	
		CHECK_ARG_F( "player damage =", ini_player_damage );
		CHECK_ARG_F( "enemy damage =", ini_enemy_damage );

		CHECK_ARG( "refill gadgets =", ini_refill_gadgets );
		CHECK_ARG( "refill ammo =", ini_refill_ammo );

		CHECK_ARG( "add pec points =", ini_add_pec );

		CHECK_ARG( "always allow marks =", ini_marks );
		CHECK_ARG( "always allow marks =", ini_marks_flag );
	}




	fclose(fp);
}
