#include <windows.h>

#include "Ini.h"
#include "Inject.h"




#define VK_TILDE VK_OEM_3
#define VK_BACKSLASH VK_OEM_5


#define VK_0 0x30
#define VK_1 0x31
#define VK_2 0x32
#define VK_9 0x39


#define CHECK_KEY(x) ( GetKeyState(x) < 0 )



// #################################################### //
// #################################################### //
// #################################################### //
// #################################################### //



static void Hotkey_Health()
{
	static bool bounce = 0;



	if( CHECK_KEY( VK_HOME ) )
	{
		if( CHECK_KEY( VK_MENU ) && ( bounce == 0 ) )
		{
			bounce = 1;


			ini_health = ini_health ? 0 : 1;
		}
	}


	// debounce
	else
		bounce = 0;
}




static void Hotkey_Pec()
{
	static bool bounce = 0;



	if( CHECK_KEY( VK_INSERT ) )
	{
		if( CHECK_KEY( VK_MENU ) && ( bounce == 0 ) )
		{
			bounce = 1;


			ini_add_pec_flag++;
		}
	}


	// debounce
	else
		bounce = 0;
}




static void Hotkey_Marks()
{
	static bool bounce = 0;



	if( CHECK_KEY( VK_DELETE ) )
	{
		if( CHECK_KEY( VK_MENU ) && ( bounce == 0 ) )
		{
			bounce = 1;


			ini_marks_flag = ini_marks_flag ? 0 : 1;
	
			if( ini_marks == 0 ) ini_marks = 1;
		}
	}


	// debounce
	else
		bounce = 0;
}




static DWORD WINAPI StartHotkey( LPVOID param )
{
	while(1)
	{
		Hotkey_Health();
		Hotkey_Pec();
		Hotkey_Marks();



		Sleep(1);
	}
}



// ####################################################### //
// ####################################################### //
// ####################################################### //
// ####################################################### //



static FILETIME lastWriteTime;



static void CheckIni()
{
	HANDLE hFile;
	FILETIME fileTime;
	
	
	hFile = CreateFile( "scripts\\Trainer.ini", 0, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
	if( !hFile )
	{
		hFile = CreateFile( "scripts_asi\\Trainer.ini", 0, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
		if( !hFile ) return;
	}




	GetFileTime( hFile, NULL, NULL, &fileTime );

	if( memcmp( &lastWriteTime, &fileTime, sizeof(fileTime) ) != 0 )
	{
		ReadIni();


		memcpy( &lastWriteTime, &fileTime, sizeof(fileTime) );
	}



	CloseHandle( hFile );
}




static DWORD WINAPI UpdateHotkey( LPVOID param )
{
	while(1)
	{
		CheckIni();



		Sleep(25);
	}
}



// ####################################################### //
// ####################################################### //
// ####################################################### //
// ####################################################### //



void Hotkey()
{
	DWORD threadId;
	HANDLE hThread;



	hThread = CreateThread( NULL, 0, StartHotkey, 0, 0, &threadId );
	CloseHandle( hThread );


	hThread = CreateThread( NULL, 0, UpdateHotkey, 0, 0, &threadId );
	CloseHandle( hThread );
}
