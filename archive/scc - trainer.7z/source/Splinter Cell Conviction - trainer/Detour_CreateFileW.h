static HANDLE __stdcall DetourCreateFileW_code( UINT8 *stack )
{
	WCHAR strwName[1024];



	wcsncpy( strwName, *(const WCHAR **) stack, 1024 );
	DetourCreateFile_shared( strwName );



	// replace file name
	READ32(stack) = (UINT32) &strwName;



	HANDLE result = pCreateFileW( (LPTSTR) READ32( stack + 0 ), READ32( stack + 4 ), READ32( stack + 8 ), (LPSECURITY_ATTRIBUTES) READ32(stack + 12),
																READ32( stack + 16 ), READ32( stack + 20 ), (HANDLE) READ32( stack + 24 ) );

	return result;
}




static HANDLE __declspec(naked) DetourCreateFileW_asm( 
	LPTSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition,
  DWORD dwFlagsAndAttributes, HANDLE hTemplateFile )
{
	// avoid compiler generated code
	// - inline register corruption, security cookie

	__asm
	{
		push ebp


		// push ebp + ret ==> original args
		mov ebp,esp
		add ebp,8



		// temp var = result
		push eax


		// ******************************************************** //
		// ******************************************************** //
		// ******************************************************** //


		// preserve registers for post-trampoline
		pushad
		pushfd


		push ebp
		call DetourCreateFileW_code


		// save return code
		mov [esp + 4 + 32], eax


		popfd
		popad


		// ******************************************************** //
		// ******************************************************** //
		// ******************************************************** //


		// return result
		pop eax



		// __stdcall cleanup
		pop ebp
		ret 28
	}
}
