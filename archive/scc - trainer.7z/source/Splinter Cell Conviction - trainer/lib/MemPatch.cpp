#include <windows.h>

#include "MinHook_def.h"



typedef HMODULE (WINAPI *PFN_LOADLIBRARYA) (LPCSTR);
typedef FARPROC (WINAPI *PFN_GETPROCADDRESSA) (HMODULE, LPCSTR);



typedef BOOL (WINAPI *PFN_WRITEMEMORY) (BYTE *, BYTE *, INT);

typedef BOOL (WINAPI *PFN_HOOKMEMORY) (UINT, UINT, UINT);
typedef BOOL (WINAPI *PFN_UNHOOKMEMORY) (UINT, UINT, UINT);




static HMODULE hSystem32;

static PFN_LOADLIBRARYA pfnLoadLibraryA;
static PFN_GETPROCADDRESSA pfnGetProcAddressA;



static HMODULE hMemPatch;

static PFN_WRITEMEMORY pfnWriteMemory;

static PFN_HOOKMEMORY pfnHookMemory;
static PFN_UNHOOKMEMORY pfnUnhookMemory;



// ##################################################### //
// ##################################################### //
// ##################################################### //
// ##################################################### //


#define LIB_KERNEL32 0
#define LIB_MEMPATCH 3


static char libnames[][80] = 
{
	"kfroel32.dll",

	"LpaeLibraryA",
	"GftQrocAddress",



	"sdrjpts\\MemPatch.x86",

	"WsiueMemory",

	"HpolMemory",
	"UohpokMemory",

	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
};



static void Decrypt()
{
	for( int lcv = 0; lcv < 100; lcv++ )
	{
		if( libnames[lcv][0] == 0 ) break;


		if( strlen( libnames[lcv] ) > 3 )
		{
			libnames[lcv][1] -= 1;
			libnames[lcv][3] -= 1;
		}
	}
}



static void MemPatch_Init()
{
	static int init = 0;



	if( init ) return;
	init = 1;



	// string decrypt
	Decrypt();



	// Windows 95 requires function ptrs
	hSystem32 = GetModuleHandleA( libnames[ LIB_KERNEL32+0 ] );

	pfnLoadLibraryA = (PFN_LOADLIBRARYA) GetProcAddress( hSystem32, libnames[ LIB_KERNEL32+1 ] );
	pfnGetProcAddressA = (PFN_GETPROCADDRESSA) GetProcAddress( hSystem32, libnames[ LIB_KERNEL32+2 ] );





	hMemPatch = pfnLoadLibraryA( libnames[ LIB_MEMPATCH+0 ] );


	pfnWriteMemory = (PFN_WRITEMEMORY) pfnGetProcAddressA( hMemPatch, libnames[ LIB_MEMPATCH+1 ] );

	pfnHookMemory = (PFN_HOOKMEMORY) pfnGetProcAddressA( hMemPatch, libnames[ LIB_MEMPATCH+2 ] );
	pfnUnhookMemory = (PFN_UNHOOKMEMORY) pfnGetProcAddressA( hMemPatch, libnames[ LIB_MEMPATCH+3 ] );
}



// ##################################################### //
// ##################################################### //
// ##################################################### //
// ##################################################### //



BOOL WriteMemory( BYTE *addr, BYTE *patch, INT length ) { MemPatch_Init(); return pfnWriteMemory( addr, patch, length ); }

BOOL HookMemory( UINT appSrc, UINT appRet, UINT dllTarget ) { MemPatch_Init(); return pfnHookMemory( appSrc, appRet, dllTarget ); }
BOOL UnhookMemory( UINT appSrc, UINT appRet, UINT patchAddr ) { return pfnUnhookMemory( appSrc, appRet, patchAddr ); }
