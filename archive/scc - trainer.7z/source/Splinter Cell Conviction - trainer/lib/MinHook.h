extern void MH_Load();

extern DWORD MH_Initialize();
extern DWORD MH_Uninitialize();

extern DWORD MH_CreateHook(void* pTarget, void* const pDetour, void** ppOriginal);
extern DWORD MH_RemoveHook(void* pTarget);

extern void MH_EnableHook(void* pTarget);
extern void MH_DisableHook(void* pTarget);

extern DWORD MH_QueueEnableHook(void* pTarget);
extern DWORD MH_QueueDisableHook(void* pTarget);

extern DWORD MH_ApplyQueued();
extern DWORD MH_GetError();
