#include <windows.h>

#include "MinHook_def.h"



typedef HMODULE (WINAPI *PFN_LOADLIBRARYA) (LPCSTR);
typedef FARPROC (WINAPI *PFN_GETPROCADDRESSA) (HMODULE, LPCSTR);


typedef MH_STATUS (WINAPI *PFN_MHINITIALIZE) ();
typedef MH_STATUS (WINAPI *PFN_MHUNINITIALIZE) ();

typedef MH_STATUS (WINAPI *PFN_MHCREATEHOOK) (void* , void* const, void**);
typedef MH_STATUS (WINAPI *PFN_MHREMOVEHOOK) (void*);

typedef MH_STATUS (WINAPI *PFN_MHENABLEHOOK) (void*);
typedef MH_STATUS (WINAPI *PFN_MHDISABLEHOOK) (void*);

typedef MH_STATUS (WINAPI *PFN_MHQUEUEENABLEHOOK) (void*);
typedef MH_STATUS (WINAPI *PFN_MHQUEUEDISABLEHOOK) (void*);

typedef MH_STATUS (WINAPI *PFN_MHAPPLYQUEUED) ();





static HMODULE hSystem32;

static PFN_LOADLIBRARYA pfnLoadLibraryA;
static PFN_GETPROCADDRESSA pfnGetProcAddressA;



static HMODULE hMinHook;

static PFN_MHINITIALIZE pfnMHInitialize;
static PFN_MHUNINITIALIZE pfnMHUninitialize;

static PFN_MHCREATEHOOK pfnMHCreateHook;
static PFN_MHREMOVEHOOK pfnMHRemoveHook;

static PFN_MHENABLEHOOK pfnMHEnableHook;
static PFN_MHDISABLEHOOK pfnMHDisableHook;

static PFN_MHQUEUEENABLEHOOK pfnMHQueueEnableHook;
static PFN_MHQUEUEDISABLEHOOK pfnMHQueueDisableHook;

static PFN_MHAPPLYQUEUED pfnMHApplyQueued;



static DWORD MH_error;



// ##################################################### //
// ##################################################### //
// ##################################################### //
// ##################################################### //



#define LIB_KERNEL32 0
#define LIB_MINHOOK 3



static char libNames[][80] = 
{
	"kfroel32.dll",

	"LpaeLibraryA",
	"GftQrocAddress",



	"sdrjpts\\MinHook.x86",
	"sdrjpts_asi\\MinHook.x86",


	"",
	"",
	"",
	"",
};




static char dllNames[][80] = 
{
	"MI_Jnitialize",
	"MI_Vninitialize",

	"MI_DreateHook",
	"MI_SemoveHook",

	"MI_FnableHook",
	"MI_EisableHook",

	"MI_RueueEnableHook",
	"MI_RueueDisableHook",

	"MI_BpplyQueued",

	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
};




static void Decrypt()
{
	int lcv;


	for( lcv = 0; lcv < 100; lcv++ )
	{
		if( libNames[lcv][0] == 0 ) break;


		libNames[lcv][1] -= 1;
		libNames[lcv][3] -= 1;
	}



	for( lcv = 0; lcv < 100; lcv++ )
	{
		if( dllNames[lcv][0] == 0 ) break;


		dllNames[lcv][1] -= 1;
		dllNames[lcv][3] -= 1;
	}
}



// ##################################################### //
// ##################################################### //
// ##################################################### //
// ##################################################### //



void MH_Load()
{
	if( hSystem32 ) return;



	// string decrypt
	Decrypt();



	hSystem32 = GetModuleHandleA( libNames[ LIB_KERNEL32+0 ] );

	pfnLoadLibraryA = (PFN_LOADLIBRARYA) GetProcAddress( hSystem32, libNames[ LIB_KERNEL32+1 ] );
	pfnGetProcAddressA = (PFN_GETPROCADDRESSA) GetProcAddress( hSystem32, libNames[ LIB_KERNEL32+2 ] );




	hMinHook = pfnLoadLibraryA( libNames[ LIB_MINHOOK+0 ] );
	if( !hMinHook )
		hMinHook = pfnLoadLibraryA( libNames[ LIB_MINHOOK+1 ] );



	pfnMHInitialize = (PFN_MHINITIALIZE) pfnGetProcAddressA( hMinHook, dllNames[0] );
	pfnMHUninitialize = (PFN_MHUNINITIALIZE) pfnGetProcAddressA( hMinHook, dllNames[1] );

	pfnMHCreateHook = (PFN_MHCREATEHOOK) pfnGetProcAddressA( hMinHook, dllNames[2] );
	pfnMHRemoveHook = (PFN_MHREMOVEHOOK) pfnGetProcAddressA( hMinHook, dllNames[3] );

	pfnMHEnableHook = (PFN_MHENABLEHOOK) pfnGetProcAddressA( hMinHook, dllNames[4] );
	pfnMHDisableHook = (PFN_MHDISABLEHOOK) pfnGetProcAddressA( hMinHook, dllNames[5] );

	pfnMHQueueEnableHook = (PFN_MHQUEUEENABLEHOOK) pfnGetProcAddressA( hMinHook, dllNames[6] );
	pfnMHQueueDisableHook = (PFN_MHQUEUEDISABLEHOOK) pfnGetProcAddressA( hMinHook, dllNames[7] );

	pfnMHApplyQueued = (PFN_MHAPPLYQUEUED) pfnGetProcAddressA( hMinHook, dllNames[8] );
}




DWORD MH_Initialize()
{
	MH_Load();


	MH_error = pfnMHInitialize();
	return MH_error;
}




DWORD MH_Uninitialize() { return pfnMHUninitialize(); }


DWORD MH_QueueEnableHook(void* pTarget) {	MH_error = pfnMHQueueEnableHook( pTarget ); return MH_error; }
DWORD MH_QueueDisableHook(void* pTarget) {	MH_error = pfnMHQueueDisableHook( pTarget ); return MH_error; }


void MH_EnableHook(void* pTarget) { pfnMHEnableHook( pTarget ); }
void MH_DisableHook(void* pTarget) { pfnMHDisableHook( pTarget ); }


DWORD MH_CreateHook(void* pTarget, void* const pDetour, void** ppOriginal) { MH_error = pfnMHCreateHook( pTarget, pDetour, ppOriginal ); return MH_error; }
DWORD MH_RemoveHook(void* pTarget) { pfnMHRemoveHook( pTarget ); return MH_error; }


DWORD MH_ApplyQueued() { MH_error = pfnMHApplyQueued(); return MH_error; }
DWORD MH_GetError() { return MH_error; };
