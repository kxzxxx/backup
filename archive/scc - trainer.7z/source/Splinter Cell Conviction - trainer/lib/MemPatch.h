#define SWAP32(x) \
	( \
		( ((x>>0) & 0xff) << 24 ) | \
		( ((x>>8) & 0xff) << 16 ) | \
		( ((x>>16) & 0xff) << 8 ) | \
		( ((x>>24) & 0xff) << 0 ) \
	)

#define SWAP16(x) \
	( \
		( ((x>>0) & 0xff) << 8 ) | \
		( ((x>>8) & 0xff) << 0 ) \
	)


#define UINT8 unsigned char
#define UINT16 unsigned short
#define UINT32 unsigned int


#ifndef READ32
#define READ32(x) (* ((UINT32 *) (x)) )
#endif



// ########################################### //
// ########################################### //
// ########################################### //
// ########################################### //



extern BOOL WriteMemory( BYTE *addr, BYTE *patch, INT length );

extern BOOL HookMemory( UINT appSrc, UINT appRet, UINT dllTarget );
extern BOOL UnhookMemory( UINT appSrc, UINT appRet, UINT patchAddr );
