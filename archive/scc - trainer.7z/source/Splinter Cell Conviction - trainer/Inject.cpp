#include "windows.h"

#include "lib\MemPatch.h"
#include "Detour.h"

#include "Retail_104.h"



static int version;
static WCHAR strw[256];

static int imagebase;



// ############################################################# //
// ############################################################# //
// ############################################################# //
// ############################################################# //


int AddBase( int addr )
{
	return imagebase + addr;
}




static void Inject1( WCHAR *fileName )
{
	static int init = 0;


	if( init ) return;
	if( wcsstr( fileName, L"menu_sound.occ" ) == 0 ) return;



	imagebase = (INT) GetModuleHandle(NULL);
	DWORD val = *((DWORD *) ( imagebase + 0x20000 ) );


	//wsprintfW( strw, L"@@@  base = %X, id = %X", imagebase, val );
	//Print_Message( strw );


	// ************************************************* //
	// ************************************************* //
	// ************************************************* //


	// Warning: Possible re-patch of bad bytes
	//          Hopefully this spot is far enough to avoid problems


/*
Conviction_game.exe+1FFFE - A3 B0F34101           - mov [Conviction_game.exe+101F3B0],eax
Conviction_game.exe+20003 - E8 7F700700           - call Conviction_game.exe+97087
*/


	if( val == SWAP32( 0xF34101E8 ) )
	{
		Inject_Retail_104();


		version = 104;
		init = 1;
	}
}




void Inject_CreateFile( WCHAR *fileName )
{
	Inject1( fileName );
}
