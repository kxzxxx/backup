#include "windows.h"
#include <stdio.h>

#include "Detour.h"
#include "lib\MemPatch.h"
#include "lib\MinHook.h"

#include "Inject.h"



static CRITICAL_SECTION printlog_lock;



// #################################################### //
// #################################################### //
// #################################################### //
// #################################################### //



void Print_Message( WCHAR *str )
{
	static FILE *log = 0;


#ifndef DEBUG_LOG
	return;
#endif


	if( log == 0 )
	{
		log = _wfopen( L"debug - trainer.txt", L"w" );

		return;
	}
	if( !log ) return;


	// ************************************************** //
	// ************************************************** //
	// ************************************************** //


	EnterCriticalSection( &printlog_lock );


	if( str )
	{
		fwprintf( log, str );
		fwprintf( log, L"\n" );
	}

	else
		fwprintf( log, L"<NULL>\n" );


	fflush( log );


	LeaveCriticalSection( &printlog_lock );
}



// #################################################### //
// #################################################### //
// #################################################### //
// #################################################### //


#include "Detour_CreateFile.h"




void Detour()
{
	InitializeCriticalSection( &printlog_lock );



	// create log file before detour starts!!
	Print_Message( L"" );



	MH_Load();


	Hook_CreateFile();


	MH_ApplyQueued();
}




void Detour_Stop()
{
	Unhook_CreateFile();


	LeaveCriticalSection( &printlog_lock );
	DeleteCriticalSection( &printlog_lock );
}
