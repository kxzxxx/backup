/*
===>
Conviction_game.exe+144DDA - FF 8B 00080000        - dec [ebx+00000800]
===>


Conviction_game.exe+144DE0 - D9 9B 80080000        - fstp dword ptr [ebx+00000880]
Conviction_game.exe+144DE6 - D9E8                  - fld1 
Conviction_game.exe+144DE8 - 6A 00                 - push 00
Conviction_game.exe+144DEA - 51                    - push ecx
*/


static int emp_call = 0x144dda;
static int emp_retn = 0x144de0;



static void __declspec(naked) emp_asm()
{
	__asm
	{
		// OLD code
		dec dword ptr [ebx + 0x800]


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


		cmp ini_refill_gadgets, 0
		je done


		// portable emp
		cmp dword ptr [ebx + 0x800], 0
		jne done



		push eax
		mov eax, ini_refill_gadgets
		mov [ebx + 0x800], eax
		pop eax


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


done:
		push emp_retn
		ret
	}
}




// ################################################ //
// ################################################ //
// ################################################ //
// ################################################ //



static void Hook_Emp()
{
	if(1)
	{
		emp_retn = AddBase( emp_retn );



		HookMemory( AddBase(emp_call), emp_retn, (UINT) &emp_asm );
	}
}
