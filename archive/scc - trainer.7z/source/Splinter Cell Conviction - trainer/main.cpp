#include "windows.h"
#include <stdio.h>


#include "Detour.h"
#include "Ini.h"
#include "Hotkey.h"



static HMODULE hModuleLock;




static DWORD WINAPI SafeStart( LPVOID param )
{
	return 0;
}




BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		// ignore thread creation messages
		DisableThreadLibraryCalls( hModule );



		// prevent early unloading while background thread running
		char name[1024];

		GetModuleFileNameA( hModule, (LPCH) &name, 1024 );
		hModuleLock = LoadLibraryA( name );




		// outside of DLL lock, do normal stuff
		DWORD threadId;
		HANDLE hSafeStart;


		//hSafeStart = CreateThread( NULL, 0, SafeStart, 0, 0, &threadId );
		//CloseHandle( hSafeStart );


		ReadIni();
		Detour();
		Hotkey();
		break;



	case DLL_PROCESS_DETACH:
		Detour_Stop();


		// release DLL - all threads closed
		FreeLibrary( hModuleLock );
		break;
	};


	return TRUE;
}
