/*
===>
Conviction_game.exe+37A7A6 - 8B 40 5C              - mov eax,[eax+5C]
Conviction_game.exe+37A7A9 - 89 06                 - mov [esi],eax
===>


Conviction_game.exe+37A7AB - 33 C0                 - xor eax,eax
Conviction_game.exe+37A7AD - 3B F8                 - cmp edi,eax
Conviction_game.exe+37A7AF - 0F85 30010000         - jne Conviction_game.exe+37A8E5
*/


static int pec_call = 0x37a7a6;
static int pec_retn = 0x37a7ab;



static void __declspec(naked) pec_asm()
{
	__asm
	{
		cmp ini_add_pec_flag, 0
		je done



		push ebx

		mov ebx, ini_add_pec
		add [eax + 0x5c], ebx
		mov ini_add_pec_flag, 0

		pop ebx


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


done:
		// OLD code
		mov eax, [eax + 0x5C]
		mov [esi], eax



		push pec_retn
		ret
	}
}




// ################################################ //
// ################################################ //
// ################################################ //
// ################################################ //



static void Hook_Pec()
{
	if(1)
	{
		pec_retn = AddBase( pec_retn );



		HookMemory( AddBase(pec_call), pec_retn, (UINT) &pec_asm );
	}
}
