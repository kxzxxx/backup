CRITICAL_SECTION createfile_lock;



typedef HANDLE (WINAPI *CREATEFILEW) (
	LPCTSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition,
  DWORD dwFlagsAndAttributes, HANDLE hTemplateFile );


typedef HANDLE (WINAPI *CREATEFILEA) (
	LPTSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition,
  DWORD dwFlagsAndAttributes, HANDLE hTemplateFile );



static CREATEFILEA pCreateFileA = NULL;
static CREATEFILEW pCreateFileW = NULL;



// ################################################## //
// ################################################## //
// ################################################## //
// ################################################## //



HANDLE __stdcall RealCreateFileW( WCHAR *filename, DWORD access, DWORD openMode )
{
	// access = NULL, GENERIC_READ, GENERIC_WRITE
	// openMode = CREATE_ALWAYS, CREATE_NEW, OPEN_ALWAYS, OPEN_EXISTING


	return pCreateFileW( (LPCTSTR) filename, access, FILE_SHARE_READ, NULL, openMode, NULL, NULL );
}




static VOID DetourCreateFile_shared( WCHAR *lpFileName )
{
	EnterCriticalSection( &createfile_lock );
	Print_Message( lpFileName );


	Inject_CreateFile( lpFileName );


	LeaveCriticalSection( &createfile_lock );
}



// ########################################################### //
// ########################################################### //
// ########################################################### //
// ########################################################### //


#include "Detour_CreateFileA.h"
#include "Detour_CreateFileW.h"



static void Hook_CreateFile()
{
	InitializeCriticalSection( &createfile_lock );


	MH_CreateHook( &CreateFileW, &DetourCreateFileW_asm, reinterpret_cast<void**>(&pCreateFileW) );
	MH_CreateHook( &CreateFileA, &DetourCreateFileA_asm, reinterpret_cast<void**>(&pCreateFileA) );
}



static void Unhook_CreateFile()
{
	LeaveCriticalSection( &createfile_lock );
	DeleteCriticalSection( &createfile_lock );
}
