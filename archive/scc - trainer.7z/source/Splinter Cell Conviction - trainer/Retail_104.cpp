#include <windows.h>

#include "lib\MemPatch.h"
#include "Inject.h"
#include "Ini.h"



// ######################################################### //
// ######################################################### //
// ######################################################### //
// ######################################################### //



#include "Retail_104_health.h"
#include "Retail_104_emp.h"
#include "Retail_104_ammo.h"
#include "Retail_104_pec.h"
#include "Retail_104_marks.h"




void Inject_Retail_104()
{
	Hook_Health();
	Hook_Emp();
	Hook_Ammo();
	Hook_Pec();
	Hook_Marks();
}
