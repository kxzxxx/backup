extern int ini_health;

extern float ini_player_damage;
extern float ini_enemy_damage;

extern int ini_refill_gadgets;
extern int ini_refill_ammo;

extern int ini_add_pec;
extern int ini_add_pec_flag;

extern int ini_marks;
extern int ini_marks_flag;



extern void ReadIni();
