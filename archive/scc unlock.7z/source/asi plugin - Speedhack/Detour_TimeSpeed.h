void SetTimeSpeed( float speed )
{
	SetGetTickCount_Speed( speed );
	SetQueryPerformanceCounter_Speed( speed );
	SetTimeGetTime_Speed( speed );
}
