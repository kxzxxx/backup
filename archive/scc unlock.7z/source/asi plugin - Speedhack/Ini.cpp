#include <stdio.h>
#include <string.h>


static char line[1024];



float speedrate_1 = 1.0f;
float speedrate_2 = 1.0f;

char speedkey_1[80];
char speedkey_2[80];



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



void ReadIni()
{
	FILE *fp;


	fp = fopen( "scripts\\Speedhack.ini", "r" );
	if( !fp )
	{
		fp = fopen( "scripts_asi\\Speedhack.ini", "r" );
		if( !fp ) return;
	}



	while(1)
	{
		if( feof(fp) ) break;


		fgets( line, 1024, fp );



#define CHECK_ARG_STR(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%s", &y ); \
		continue; \
	}



#define CHECK_ARG(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%d", &y ); \
		continue; \
	}



#define CHECK_ARG_F(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%f", &y ); \
		continue; \
	}



		//CHECK_ARG( "debug log =", ini_debug_log );


		CHECK_ARG_F( "speed rate 1 =", speedrate_1 );
		CHECK_ARG_F( "speed rate 2 =", speedrate_2 );


		CHECK_ARG_STR( "toggle key 1 =", speedkey_1 );
		CHECK_ARG_STR( "toggle key 2 =", speedkey_2 );
	}


	fclose(fp);
}
