typedef MMRESULT (WINAPI *TIMEBEGINPERIOD) (DWORD);
typedef MMRESULT (WINAPI *TIMEENDPERIOD) (DWORD);



static TIMEBEGINPERIOD pTimeBeginPeriod;
static TIMEENDPERIOD pTimeEndPeriod;



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



static MMRESULT __declspec(naked) DetourTimeBeginPeriod_asm()
{
	// avoid compiler generated code
	// - inline register corruption, security cookie

	__asm
	{
		push 1
		call pTimeBeginPeriod


		ret 4
	}
}




static MMRESULT __declspec(naked) DetourTimeEndPeriod_asm()
{
	// avoid compiler generated code
	// - inline register corruption, security cookie

	__asm
	{
		push 1
		call pTimeEndPeriod


		ret 4
	}
}



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



static void Hook_TimePeriod()
{
	if( !MH_CreateHook( (void *) timeBeginPeriod, &DetourTimeBeginPeriod_asm, reinterpret_cast<void**>(&pTimeBeginPeriod) ) ) PrintMsg( L"timeBeginPeriod", &pTimeBeginPeriod );
	if( !MH_CreateHook( (void *) timeEndPeriod, &DetourTimeEndPeriod_asm, reinterpret_cast<void**>(&pTimeEndPeriod) ) ) PrintMsg( L"timeEndPeriod", &pTimeEndPeriod );
}




static void Unhook_TimePeriod()
{
}
