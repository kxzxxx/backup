extern float speedrate_1;
extern float speedrate_2;

extern char speedkey_1[80];
extern char speedkey_2[80];



extern void ReadIni();
