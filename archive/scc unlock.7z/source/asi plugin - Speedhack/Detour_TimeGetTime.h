typedef DWORD (WINAPI *TIMEGETTIME) (VOID);



static CRITICAL_SECTION timeGetTime_lock;
static TIMEGETTIME pTimeGetTime;


static DWORD timeGetTime_adjust = 0;
static DWORD timeGetTime_real = 0;

static DWORD timeGetTime_speed = 1 * 10;



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



static void SetTimeGetTime_Speed( float speed )
{
	EnterCriticalSection( &timeGetTime_lock );

	timeGetTime_speed = (DWORD) speed * 10;

	LeaveCriticalSection( &timeGetTime_lock );
}




static DWORD __stdcall DetourTimeGetTime_code( UINT8 *stack )
{
	DWORD time, delta;


	time = pTimeGetTime();




	EnterCriticalSection( &timeGetTime_lock );


	// *********************************************** //
	// *********************************************** //
	// *********************************************** //


	static int init = 0;



	// safety
	if( init == 0 )
	{
		timeGetTime_real = time;
		timeGetTime_adjust = time;


		init = 1;
	}




	// overflow or timing glitch??
	delta = time - timeGetTime_real;
	if( (int) delta < 0 ) delta = -delta;




	// delta time = 0.1 - 100000x
	timeGetTime_adjust += ( delta * timeGetTime_speed ) / 10;




	// update times
	timeGetTime_real = time;

	time = timeGetTime_adjust;


	// *********************************************** //
	// *********************************************** //
	// *********************************************** //


	LeaveCriticalSection( &timeGetTime_lock );


	return time;
}




static DWORD __declspec(naked) DetourTimeGetTime_asm()
{
	// avoid compiler generated code
	// - inline register corruption, security cookie

	__asm
	{
		push ebp


		// push + ret  (8 bytes) ==> args
		mov ebp,esp
		add ebp,8




		// preserve registers for post-trampoline
		pushad
		pushfd


		push ebp
		call DetourTimeGetTime_code


		// save return code
		mov [esp + 4 + 32 - 4], eax


		popfd
		popad



		// __stdcall cleanup
		pop ebp
		ret 0
	}
}



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



static void Hook_TimeGetTime()
{
	InitializeCriticalSection( &timeGetTime_lock );


	if( !MH_CreateHook( (void *) timeGetTime, &DetourTimeGetTime_asm, reinterpret_cast<void**>(&pTimeGetTime) ) ) PrintMsg( L"timeGetTime", &pTimeGetTime );
}




static void Unhook_TimeGetTime()
{
	LeaveCriticalSection( &timeGetTime_lock );


	DeleteCriticalSection( &timeGetTime_lock );
}
