#include <windows.h>
#include "Ini.h"



#define VK_OEM_3 0xc0
#define VK_OEM_5 0xdc



#define VK_TILDE VK_OEM_3
#define VK_BACKSLASH VK_OEM_5




static int speedToggle;
static int key1 = VK_BACKSLASH;
static int key2 = VK_TILDE;




#define CHECK_KEY(x) ( GetKeyState(x) < 0 )


extern void SetTimeSpeed( float speed );



// #################################################### //
// #################################################### //
// #################################################### //
// #################################################### //



static void Hotkey_Speed1()
{
	static bool bounce = 0;



	// speed toggle 1
	if( CHECK_KEY( key1 ) )
	{
		if( CHECK_KEY( VK_MENU ) && ( bounce == 0 ) )
		{
			if( speedToggle != 1 )
			{
				bounce = 1;
				speedToggle = 1;



				SetTimeSpeed( speedrate_1 );
			}


			else
			{
				bounce = 1;
				speedToggle = 0;



				SetTimeSpeed( 1.0f );
			}
		}
	}


	// debounce
	else
		bounce = 0;
}




static void Hotkey_Speed2()
{
	static bool bounce = 0;



	// speed toggle 2
	if( CHECK_KEY( key2 ) )
	{
		if( CHECK_KEY( VK_MENU ) && ( bounce == 0 ) )
		{
			if( speedToggle != 2 )
			{
				bounce = 1;
				speedToggle = 2;



				SetTimeSpeed( speedrate_2 );
			}


			else
			{
				bounce = 1;
				speedToggle = 0;



				SetTimeSpeed( 1.0f );
			}
		}
	}


	// debounce
	else
		bounce = 0;
}




static DWORD WINAPI StartHotkey( LPVOID param )
{
	while(1)
	{
		Hotkey_Speed1();
		Hotkey_Speed2();


		Sleep(1);
	}
}



// ####################################################### //
// ####################################################### //
// ####################################################### //
// ####################################################### //



static FILETIME lastWriteTime;



static void CheckIni()
{
	HANDLE hFile;
	FILETIME fileTime;



	hFile = CreateFile( "scripts\\Speedhack.ini", 0, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
	if( !hFile )
	{
		hFile = CreateFile( "scripts_asi\\Speedhack.ini", 0, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
		if( !hFile ) return;
	}




	GetFileTime( hFile, NULL, NULL, &fileTime );

	if( memcmp( &lastWriteTime, &fileTime, sizeof(fileTime) ) != 0 )
	{
		ReadIni();



		// update timers
		if( speedToggle == 1 ) SetTimeSpeed( speedrate_1 );
		if( speedToggle == 2 ) SetTimeSpeed( speedrate_2 );



		// reassign keys
		if( stricmp( speedkey_1, "tilde" ) == 0 ) key1 = VK_TILDE;
		if( stricmp( speedkey_1, "backspace" ) == 0 ) key1 = VK_BACK;
		if( stricmp( speedkey_1, "backslash" ) == 0 ) key1 = VK_BACKSLASH;
		if( stricmp( speedkey_1, "tab" ) == 0 ) key1 = VK_TAB;


		if( stricmp( speedkey_2, "tilde" ) == 0 ) key2 = VK_TILDE;
		if( stricmp( speedkey_2, "backspace" ) == 0 ) key2 = VK_BACK;
		if( stricmp( speedkey_2, "backslash" ) == 0 ) key2 = VK_BACKSLASH;
		if( stricmp( speedkey_2, "tab" ) == 0 ) key2 = VK_TAB;
	}



	CloseHandle( hFile );
}




static DWORD WINAPI UpdateHotkey( LPVOID param )
{
	while(1)
	{
		CheckIni();



		Sleep(500);
	}
}



// ####################################################### //
// ####################################################### //
// ####################################################### //
// ####################################################### //



void Hotkey()
{
	DWORD threadId;
	HANDLE hThread;



	hThread = CreateThread( NULL, 0, StartHotkey, 0, 0, &threadId );
	CloseHandle( hThread );


	hThread = CreateThread( NULL, 0, UpdateHotkey, 0, 0, &threadId );
	CloseHandle( hThread );
}
