typedef BOOL (WINAPI *QUERYPERFORMANCECOUNTER) (LARGE_INTEGER *);



static CRITICAL_SECTION queryPerformanceCounter_lock;
static QUERYPERFORMANCECOUNTER pQueryPerformanceCounter;


static LARGE_INTEGER queryPerformanceCounter_adjust;
static LARGE_INTEGER queryPerformanceCounter_real;

static DWORD queryPerformanceCounter_speed = 1 * 10;



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



static void SetQueryPerformanceCounter_Speed( float speed )
{
	EnterCriticalSection( &queryPerformanceCounter_lock );

	queryPerformanceCounter_speed = (DWORD) speed * 10;

	LeaveCriticalSection( &queryPerformanceCounter_lock );
}




static bool __stdcall DetourQueryPerformanceCounter_code( UINT8 *stack )
{
	LARGE_INTEGER time, delta;


	if( !pQueryPerformanceCounter( &time ) ) return false;



	
	EnterCriticalSection( &queryPerformanceCounter_lock );


	// *********************************************** //
	// *********************************************** //
	// *********************************************** //


	static int init = 0;



	// safety
	if( init == 0 )
	{
		queryPerformanceCounter_real.QuadPart = time.QuadPart;
		queryPerformanceCounter_adjust.QuadPart = time.QuadPart;


		init = 1;
	}




	// overflow or timing glitch??
	delta.QuadPart = queryPerformanceCounter_real.QuadPart - time.QuadPart;
	if( (int) delta.QuadPart < 0 ) delta.QuadPart = -delta.QuadPart;




	// delta time = 0.1 - 100000x
	queryPerformanceCounter_adjust.QuadPart += ( delta.QuadPart * queryPerformanceCounter_speed ) / 10;




	// update times
	queryPerformanceCounter_real.QuadPart = time.QuadPart;

	time.QuadPart = queryPerformanceCounter_adjust.QuadPart;


	// *********************************************** //
	// *********************************************** //
	// *********************************************** //


	LeaveCriticalSection( &queryPerformanceCounter_lock );



	// final result
	LARGE_INTEGER *result;

	result = (LARGE_INTEGER *) ( READ32( stack+0 ) );
	(*result).QuadPart = time.QuadPart;



	return true;
}




static BOOL __declspec(naked) DetourQueryPerformanceCounter_asm( LARGE_INTEGER *lpPerformanceCount )
{
	// avoid compiler generated code
	// - inline register corruption, security cookie

	__asm
	{
		push ebp
		push eax


		// push x2 + ret  ==> args
		mov ebp,esp
		add ebp, 8+4




		// preserve registers for post-trampoline
		pushad
		pushfd


		push ebp
		call DetourQueryPerformanceCounter_code


		// save return code
		mov [esp + 4 + 32], eax


		popfd
		popad




		// __stdcall cleanup
		pop eax
		pop ebp
		ret 4
	}
}



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



static void Hook_QueryPerformanceCounter()
{
	InitializeCriticalSection( &queryPerformanceCounter_lock );


	if( !MH_CreateHook( (void *) QueryPerformanceCounter, &DetourQueryPerformanceCounter_asm, reinterpret_cast<void**>(&pQueryPerformanceCounter) ) ) PrintMsg( L"QueryPerformanceCounter", &pQueryPerformanceCounter );
}




static void Unhook_QueryPerformanceCounter()
{
	LeaveCriticalSection( &queryPerformanceCounter_lock );


	DeleteCriticalSection( &queryPerformanceCounter_lock );
}
