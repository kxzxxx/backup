extern void Detour();
extern void Detour_Stop();

extern void Print_Message( WCHAR *str );




//#define DEBUG_LOG
