typedef DWORD (WINAPI *GETTICKCOUNT) (VOID);



static CRITICAL_SECTION getTickCount_lock;
static GETTICKCOUNT pGetTickCount;


static DWORD getTickCount_adjust = 0;
static DWORD getTickCount_real = 0;

static DWORD getTickCount_speed = 1 * 10;



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



static void SetGetTickCount_Speed( float speed )
{
	EnterCriticalSection( &getTickCount_lock );

	// 0.1 - 10000
	getTickCount_speed = (DWORD) speed * 10;

	LeaveCriticalSection( &getTickCount_lock );
}




static DWORD __stdcall DetourGetTickCount_code( UINT8 *stack )
{
	DWORD time, delta;


	time = pGetTickCount();




	EnterCriticalSection( &getTickCount_lock );


	// *********************************************** //
	// *********************************************** //
	// *********************************************** //


	static int init = 0;



	// safety
	if( init == 0 )
	{
		getTickCount_real = time;
		getTickCount_adjust = time;


		init = 1;
	}



	//WCHAR strw[256];
	//wsprintfW( strw, L"getTickCount-1 = %X, %X %X", time, getTickCount_real, getTickCount_adjust );
	//Print_Message( strw );



	// overflow or timing glitch??
	delta = time - getTickCount_real;
	if( (int) delta < 0 ) delta = -delta;




	// delta time = 0.1 - 100000x
	getTickCount_adjust += ( delta * getTickCount_speed ) / 10;


	//wsprintfW( strw, L"getTickCount-2 = %X, %X %X", time, getTickCount_real, getTickCount_adjust );
	//Print_Message( strw );




	// update times
	getTickCount_real = time;

	time = getTickCount_adjust;


	// *********************************************** //
	// *********************************************** //
	// *********************************************** //


	LeaveCriticalSection( &getTickCount_lock );


	return time;
}




static DWORD __declspec(naked) DetourGetTickCount_asm()
{
	// avoid compiler generated code
	// - inline register corruption, security cookie

	__asm
	{
		push ebp


		// push + ret  (8 bytes) ==> args
		mov ebp,esp
		add ebp,8




		// preserve registers for post-trampoline
		pushad
		pushfd


		push ebp
		call DetourGetTickCount_code


		// save return code
		mov [esp + 4 + 32 - 4], eax


		popfd
		popad



		// __stdcall cleanup
		pop ebp
		ret 0
	}
}



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



static void Hook_GetTickCount()
{
	InitializeCriticalSection( &getTickCount_lock );


	if( !MH_CreateHook( (void *) GetTickCount, &DetourGetTickCount_asm, reinterpret_cast<void**>(&pGetTickCount) ) ) PrintMsg( L"GetTickCount", &pGetTickCount );
}




static void Unhook_GetTickCount()
{
	LeaveCriticalSection( &getTickCount_lock );


	DeleteCriticalSection( &getTickCount_lock );
}
