extern void Detour();
extern void Detour_Stop();

extern void Print_Message( WCHAR *str );



extern HANDLE __stdcall RealCreateFileW( WCHAR *filename, DWORD access, DWORD openMode );



extern CRITICAL_SECTION createfile_lock;



//#define DEBUG_LOG
