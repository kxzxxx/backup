/*
===>
Conviction_game.exe+EF99C - 8B 40 08              - mov eax,[eax+08]
Conviction_game.exe+EF99F - F7 D0                 - not eax
===>


Conviction_game.exe+EF9A1 - 83 E0 01              - and eax,01
Conviction_game.exe+EF9A4 - EB 02                 - jmp Conviction_game.exe+EF9A8
*/



static int dlc_weapons_call = 0xef99c;
static int dlc_weapons_retn = 0xef9a1;



static void __stdcall dlc_weapons_code( BYTE *ptr )
{
	int code = *( ptr + 0 );


	ptr += 8;



	// normal
	if( code == 0x14 && ini_mp5sd3 ) (*ptr) = 7;
	if( code == 0x1d && ini_aks74u ) (*ptr) = 7;
	if( code == 0x16 && ini_sr2m ) (*ptr) = 7;
	if( code == 0x09 && ini_sc3000 ) (*ptr) = 7;
	if( code == 0x07 && ini_ak47 ) (*ptr) = 7;
	if( code == 0x19 && ini_scar_h ) (*ptr) = 7;
	

	// extra weapons
	if( code == 0x1b && ini_spas12 ) (*ptr) = 7;
	if( code == 0x11 && ini_p99 ) (*ptr) = 7;
	if( code == 0x15 && ini_vikhr ) (*ptr) = 7;
	if( code == 0x04 && ini_mp7a1 ) (*ptr) = 7;
	if( code == 0x18 && ini_famas ) (*ptr) = 7;
	if( code == 0x06 && ini_m3 ) (*ptr) = 7;


	if( ini_all_weapons ) (*ptr) = 7;
}




static void __declspec(naked) dlc_weapons_asm()
{
	__asm
	{
		pushad
		pushfd


		push eax

		call dlc_weapons_code


		popfd
		popad


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


		// OLD code
		mov eax, [eax + 8]
		not eax



		push dlc_weapons_retn
		retn
	}
}




// ################################################ //
// ################################################ //
// ################################################ //
// ################################################ //




static void Hook_Dlc_Weapons()
{
	if(1)
	{
		dlc_weapons_retn = AddBase( dlc_weapons_retn );



		HookMemory( AddBase(dlc_weapons_call), dlc_weapons_retn, (UINT) &dlc_weapons_asm );
	}
}
