#include <windows.h>

#include "lib\MemPatch.h"
#include "Inject.h"
#include "Detour.h"
#include "Ini.h"



// ######################################################### //
// ######################################################### //
// ######################################################### //
// ######################################################### //



#include "Retail_104_dlc_infiltration.h"
#include "Retail_104_dlc_thirdEchelon.h"

#include "Retail_104_dlc_uniforms.h"
#include "Retail_104_dlc_weapons.h"
#include "Retail_104_dlc_gadgets.h"




void Inject_Retail_104()
{
	Hook_Dlc_Infiltration();
	Hook_Dlc_ThirdEchelon();


	Hook_Dlc_Uniforms();
	Hook_Dlc_Weapons();
	Hook_Dlc_Gadgets();
}
