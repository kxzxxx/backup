/*
===>
Conviction_game.exe+9B3D2 - 8B 41 7C              - mov eax,[ecx+7C]
Conviction_game.exe+9B3D5 - D1 E8                 - shr eax,1
===>


Conviction_game.exe+9B3D7 - F7 D0                 - not eax
Conviction_game.exe+9B3D9 - 83 E0 01              - and eax,01
Conviction_game.exe+9B3DC - C3                    - ret 
*/



static int dlc_thirdechelon_call = 0x9b3c6;
static int dlc_thirdechelon_retn = 0x9b3cc;




static void __declspec(naked) dlc_thirdechelon_asm()
{
	__asm
	{
		cmp ini_third_echelon, 0
		je done


		or [ecx + 0x7c], 2


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


done:
		// OLD code
		mov eax, [ecx + 0x7c]
		shr eax, 1



		push dlc_thirdechelon_retn
		ret
	}
}




// ################################################ //
// ################################################ //
// ################################################ //
// ################################################ //




static void Hook_Dlc_ThirdEchelon()
{
	if(1)
	{
		dlc_thirdechelon_retn = AddBase( dlc_thirdechelon_retn );



		HookMemory( AddBase(dlc_thirdechelon_call), dlc_thirdechelon_retn, (UINT) &dlc_thirdechelon_asm );
	}
}
