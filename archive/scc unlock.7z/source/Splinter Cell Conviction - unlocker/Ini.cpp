#include <stdio.h>
#include <string.h>


static char line[1024];



int ini_infiltration, ini_third_echelon;
int ini_mp7a1, ini_famas, ini_vikhr, ini_p99, ini_spas12, ini_m3;
int ini_scar_h;
int ini_shadow, ini_elite, ini_akali, ini_zvezda;
int ini_mine;
int ini_mp5sd3, ini_sc3000, ini_sr2m;
int ini_ak47, ini_aks74u;
int ini_all_weapons, ini_all_uniforms;



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



void ReadIni()
{
	FILE *fp;


	fp = fopen( "scripts\\Unlocker.ini", "r" );
	if( !fp )
	{
		fp = fopen( "scripts_asi\\Unlocker.ini", "r" );
		if( !fp ) return;
	}



	while(1)
	{
		if( feof(fp) ) break;


		fgets( line, 1024, fp );



#define CHECK_ARG_STR(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%s", &y ); \
		continue; \
	}



#define CHECK_ARG(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%d", &y ); \
		continue; \
	}



#define CHECK_ARG_F(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%f", &y ); \
		continue; \
	}



#define CHECK_ARG_F_100(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%f", &temp_f ); \
		temp_f = temp_f * 100.0f; \
		y = (int) temp_f; \
		continue; \
	}




		float temp_f;



		//CHECK_ARG( "debug log =", ini_debug_log );


		CHECK_ARG( "mp7a1 =", ini_mp7a1 );
		CHECK_ARG( "famas g2 =", ini_famas );
		CHECK_ARG( "vikhr =", ini_vikhr );
		CHECK_ARG( "p99 =", ini_p99 );
		CHECK_ARG( "spas-12 =", ini_spas12 );
		CHECK_ARG( "m3 =", ini_m3 );
		CHECK_ARG( "scar-h =", ini_scar_h );
		
		CHECK_ARG( "3e shadow armor =", ini_shadow );
		CHECK_ARG( "3e elite suit =", ini_elite );
		CHECK_ARG( "vr akali =", ini_akali );
		CHECK_ARG( "vr zvezda =", ini_zvezda );

		CHECK_ARG( "proximity mine =", ini_mine );

		CHECK_ARG( "third echelon map =", ini_third_echelon );
		CHECK_ARG( "infiltration mode =", ini_infiltration );

		CHECK_ARG( "mp5-sd3 =", ini_mp5sd3 );
		CHECK_ARG( "sc3000 =", ini_sc3000 );
		CHECK_ARG( "sr-2m =", ini_sr2m );

		CHECK_ARG( "ak-47 =", ini_ak47 );
		CHECK_ARG( "aks-74u =", ini_aks74u );


		CHECK_ARG( "unlock all weapons =", ini_all_weapons );
		CHECK_ARG( "unlock all uniforms =", ini_all_uniforms );
	}




	fclose(fp);
}
