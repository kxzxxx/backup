/*
===>
Conviction_game.exe+3848AE - F6 40 0C 01           - test byte ptr [eax+0C],01
Conviction_game.exe+3848B2 - 75 25                 - jne Conviction_game.exe+3848D9
===>


Conviction_game.exe+3848B4 - FF 75 FC              - push [ebp-04]
Conviction_game.exe+3848B7 - 8B CF                 - mov ecx,edi
Conviction_game.exe+3848B9 - E8 0FAFD6FF           - call Conviction_game.exe+EF7CD
Conviction_game.exe+3848BE - F6 40 0C 04           - test byte ptr [eax+0C],04
*/



static int dlc_uniforms_call = 0x3848ae;
static int dlc_uniforms_retn = 0x3848b4;
static int dlc_uniforms_jmp = 0x3848d9;



static void __stdcall dlc_uniforms_code( BYTE *ptr )
{
	int code = *(ptr + 0);
	int camo = 0;


	ptr += 0x0c;


	// no camo - elite, eclipse, akula
	camo = 1;


	// black arrow, vympel, urban, mozdok, classified
	if( code == 0x02 || code == 0x03 || code == 0x08 || code == 0x06 || code == 0x05 )
		camo = 3;


	// zvezda, shadow, akali = exclusive dlc + camo
	if( code == 0x01 || code == 0x04 || code == 0x07 )
		camo = 7;

	

	if( ini_all_uniforms || ini_zvezda || ini_shadow || ini_akali || ini_elite )
		(*ptr) = camo;
}




static void __declspec(naked) dlc_uniforms_asm()
{
	__asm
	{
		pushad
		pushfd


		push eax

		call dlc_uniforms_code


		popfd
		popad


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


		// OLD code
		test byte ptr [eax + 0x0c], 1
		jne done_jmp

		push dlc_uniforms_retn
		retn



done_jmp:
		push dlc_uniforms_jmp
		retn
	}
}




// ################################################ //
// ################################################ //
// ################################################ //
// ################################################ //




static void Hook_Dlc_Uniforms()
{
	if(1)
	{
		dlc_uniforms_retn = AddBase( dlc_uniforms_retn );
		dlc_uniforms_jmp = AddBase( dlc_uniforms_jmp );



		HookMemory( AddBase(dlc_uniforms_call), dlc_uniforms_retn, (UINT) &dlc_uniforms_asm );
	}
}
