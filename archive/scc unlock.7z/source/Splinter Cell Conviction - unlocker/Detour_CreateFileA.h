static HANDLE __stdcall DetourCreateFileA_code( UINT8 *stack )
{
	WCHAR strwName[1024];
	CHAR strName[1024];



	mbstowcs( strwName, *((const char **) stack), 1023 );
	DetourCreateFile_shared( strwName );
	wcstombs( strName, strwName, 1023 );



	// replace file name
	READ32(stack) = (UINT32) &strName;



	HANDLE result = pCreateFileA( (LPTSTR) READ32( stack + 0 ), READ32( stack + 4 ), READ32( stack + 8 ), (LPSECURITY_ATTRIBUTES) READ32(stack + 12),
																READ32( stack + 16 ), READ32( stack + 20 ), (HANDLE) READ32( stack + 24 ) );


	return result;
}




static HANDLE __declspec(naked) DetourCreateFileA_asm(
	LPTSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition,
  DWORD dwFlagsAndAttributes, HANDLE hTemplateFile )
{
	// avoid compiler generated code
	// - inline register corruption, security cookie

	__asm
	{
		push ebp


		// push ebp + ret ==> original args
		mov ebp,esp
		add ebp,8



		// temp var = result
		push eax


		// ******************************************************** //
		// ******************************************************** //
		// ******************************************************** //


		// preserve registers for post-trampoline
		pushad
		pushfd


		push ebp
		call DetourCreateFileA_code


		// save return code
		mov [esp + 4 + 32], eax


		popfd
		popad


		// ******************************************************** //
		// ******************************************************** //
		// ******************************************************** //


		// return result
		pop eax



		// __stdcall cleanup
		pop ebp
		ret 28
	}
}
