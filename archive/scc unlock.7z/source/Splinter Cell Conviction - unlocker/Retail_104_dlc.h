/*
===>
Conviction_game.exe+9B3C6 - 8B 41 7C              - mov eax,[ecx+7C]
Conviction_game.exe+9B3C9 - C1 E8 03              - shr eax,03
===>


Conviction_game.exe+9B3CC - F7 D0                 - not eax
Conviction_game.exe+9B3CE - 83 E0 01              - and eax,01
Conviction_game.exe+9B3D1 - C3                    - ret 
*/


static int dlc_infiltration_call = 0x9b3c6;
static int dlc_infiltration_retn = 0x9b3cc;




static void __declspec(naked) dlc_infiltration_asm()
{
	__asm
	{
		cmp ini_infiltration
		je done



		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


		// OLD code
		mov eax, [ecx + 0x7c]
		shr eax, 3



		push dlc_infiltration_retn
		ret
	}
}



// ################################################ //
// ################################################ //
// ################################################ //
// ################################################ //



static void Hook_Dlc()
{
	if(1)
	{
		dlc_retn = AddBase( dlc_retn );
		dlc_addr = AddBase( dlc_addr );



		HookMemory( AddBase(dlc_call), dlc_retn, (UINT) &dlc_asm );
	}
}
