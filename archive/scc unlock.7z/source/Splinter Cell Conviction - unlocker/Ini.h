extern int ini_infiltration, ini_third_echelon;
extern int ini_mp7a1, ini_famas, ini_vikhr, ini_p99, ini_spas12, ini_m3;
extern int ini_scar_h;
extern int ini_shadow, ini_elite, ini_akali, ini_zvezda;
extern int ini_mine;
extern int ini_mp5sd3, ini_sc3000, ini_sr2m;
extern int ini_ak47, ini_aks74u;
extern int ini_all_weapons, ini_all_uniforms;



extern void ReadIni();
