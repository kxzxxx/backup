/*
===>
Conviction_game.exe+EF9F2 - 8B 40 04              - mov eax,[eax+04]
Conviction_game.exe+EF9F5 - F7 D0                 - not eax
===>


Conviction_game.exe+EF9F7 - 83 E0 01              - and eax,01
Conviction_game.exe+EF9FA - EB 02                 - jmp Conviction_game.exe+EF9FE
*/



static int dlc_gadgets_call = 0xef9f2;
static int dlc_gadgets_retn = 0xef9f7;



static void __stdcall dlc_gadgets_code( BYTE *ptr )
{
	int code = *( ptr + 0 );


	ptr += 4;



	if( code == 0x06 && ini_mine ) (*ptr) = 7;
}




static void __declspec(naked) dlc_gadgets_asm()
{
	__asm
	{
		pushad
		pushfd


		push eax

		call dlc_gadgets_code


		popfd
		popad


		// ******************************************** //
		// ******************************************** //
		// ******************************************** //


		// OLD code
		mov eax, [eax + 4]
		not eax



		push dlc_gadgets_retn
		retn
	}
}




// ################################################ //
// ################################################ //
// ################################################ //
// ################################################ //




static void Hook_Dlc_Gadgets()
{
	if(1)
	{
		dlc_gadgets_retn = AddBase( dlc_gadgets_retn );



		HookMemory( AddBase(dlc_gadgets_call), dlc_gadgets_retn, (UINT) &dlc_gadgets_asm );
	}
}
