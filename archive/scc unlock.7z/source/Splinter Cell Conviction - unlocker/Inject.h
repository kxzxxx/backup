extern void Inject_CreateFile( WCHAR *outName );
extern void Inject_Update();



extern int AddBase( int addr );
