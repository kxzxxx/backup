// Compiler: no intrinsics, no inline  (avoid unknown errors)


#include "windows.h"
#include <stdio.h>


//#define DEBUG_CALL



static HMODULE hModuleLock;




BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		DisableThreadLibraryCalls( hModule );



		// prevent early unloading while background thread running
		char name[1024];

		GetModuleFileNameA( hModule, (LPCH) &name, 1024 );
		hModuleLock = LoadLibraryA( name );
		break;



	case DLL_PROCESS_DETACH:
		// release DLL - all threads closed
		FreeLibrary( hModuleLock );
		break;
	};



	return TRUE;
}
