// Credit: Cheat Engine forums


#include "windows.h"


// ###############################################
// ###############################################
// ###############################################


#define FAIL(x) \
	if( !(x) ) return FALSE;



typedef HMODULE (WINAPI *PFN_LOADLIBRARYA) (LPCSTR);
typedef FARPROC (WINAPI *PFN_GETPROCADDRESSA) (HMODULE, LPCSTR);

typedef BOOL (WINAPI *PFN_VIRTUALPROTECT) (LPVOID, SIZE_T, DWORD, PDWORD);
typedef BOOL (WINAPI *PFN_FLUSHINSTRUCTIONCACHE) (HANDLE, LPCVOID, SIZE_T);




static HMODULE hSystem32;

static PFN_LOADLIBRARYA pfnLoadLibraryA;
static PFN_GETPROCADDRESSA pfnGetProcAddressA;

static PFN_VIRTUALPROTECT pfnVirtualProtect;
static PFN_FLUSHINSTRUCTIONCACHE pfnFlushInstructionCache;



// #####################################################
// #####################################################
// #####################################################



#define LIB_KERNEL32 0


static char libnames[][80] = 
{
	"kfroel32.dll",

	"LpaeLibraryA",
	"GftQrocAddress",

	"VjruualProtect",
	"FmuthInstructionCache",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
};



static void Decrypt()
{
	for( int lcv = 0; lcv < 100; lcv++ )
	{
		if( libnames[lcv][0] == 0 ) break;


		if( strlen( libnames[lcv] ) > 3 )
		{
			libnames[lcv][1] -= 1;
			libnames[lcv][3] -= 1;
		}
	}
}



static void Init_Memory()
{
	static int init = 0;


	if( init ) return;
	init = 1;



	// string decrypt
	Decrypt();



	// Windows 95 requires function ptrs
	hSystem32 = GetModuleHandleA( libnames[ LIB_KERNEL32+0 ] );

	pfnLoadLibraryA = (PFN_LOADLIBRARYA) GetProcAddress( hSystem32, libnames[ LIB_KERNEL32+1 ] );
	pfnGetProcAddressA = (PFN_GETPROCADDRESSA) GetProcAddress( hSystem32, libnames[ LIB_KERNEL32+2 ] );


	pfnVirtualProtect = (PFN_VIRTUALPROTECT) pfnGetProcAddressA( hSystem32, libnames[ LIB_KERNEL32+3 ] );
	pfnFlushInstructionCache = (PFN_FLUSHINSTRUCTIONCACHE) pfnGetProcAddressA( hSystem32, libnames[ LIB_KERNEL32+4 ] );
}



static VOID FlushCache( BYTE *addr, INT size )
{
	pfnFlushInstructionCache( GetCurrentProcess(), addr, size );
}



BOOL WINAPI WriteMemory( BYTE *addr, BYTE *patch, INT length )
{
	DWORD oldProtect;


	Init_Memory();


	// allow writing into protected code memory
	FAIL( pfnVirtualProtect( addr, length, PAGE_EXECUTE_READWRITE, &oldProtect ) )


	// patch bytes
	memcpy( addr, patch, length );


	// safety - re-protect patched memory
	FAIL( pfnVirtualProtect( addr, length, oldProtect, &oldProtect ) )


	// ################################################
	// ################################################
	// ################################################

	// reset cpu cache
	FlushCache( addr, length );


	return TRUE;
}



BOOL WINAPI HookMemory( UINT appSrc, UINT appRet, UINT dllTarget )
{
	BYTE asmJmp[20] = { 0xe9 };


	// nop padding
	memset( asmJmp+1, 0x90, 20-1 );


	// app code - jmp to dll
	*(UINT32 *) (asmJmp + 1) = dllTarget - (appSrc + 5);


	// inject jmp hook
	FAIL( WriteMemory( (BYTE *) appSrc, asmJmp, appRet - appSrc ) )


	return TRUE;
}



BOOL WINAPI UnhookMemory( UINT appSrc, UINT appRet, UINT patchAddr )
{
	// put back old code
	FAIL( WriteMemory( (BYTE *) appSrc, (BYTE *) patchAddr, appRet - appSrc ) )


	return TRUE;
}
