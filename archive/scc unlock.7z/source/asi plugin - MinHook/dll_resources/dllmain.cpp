// Compiler: no intrinsics, no inline  (avoid unknown errors)


#include <Windows.h>


#include "..\src\hook.h"



static HMODULE hModuleLock;
extern CRITICAL_SECTION gCS;



BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch( ul_reason_for_call )
	{
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls( hModule );


			InitializeCriticalSection( &gCS );



			MH_Initialize();



			// prevent early unloading while background thread running
			char name[1024];

			GetModuleFileNameA( hModule, (LPCH) &name, 1024 );
			hModuleLock = LoadLibraryA( name );
			break;



		case DLL_PROCESS_DETACH:
			MH_Uninitialize();



			LeaveCriticalSection( &gCS );
			DeleteCriticalSection( &gCS );

			
			
			// release DLL - all threads closed
			FreeLibrary( hModuleLock );
			break;
	}


	return TRUE;
}
