
//  PrcHelp.h
//  Copyright (C) 2004 ApiHooks.com


#ifndef _PRCHELP_
#define _PRCHELP_ 0x546

#ifdef __cplusplus
extern "C" {
#endif
  DWORD  __stdcall PH_GetVersion(VOID *pReserved);
  LPVOID __stdcall PH_VirtualAllocEx(HANDLE hProcess, LPVOID lpAddress, DWORD dwSize, DWORD flAllocationType, DWORD flProtect);
  BOOL   __stdcall PH_VirtualFreeEx (HANDLE hProcess, LPVOID lpAddress, DWORD dwSize, DWORD dwFreeType);
  HANDLE __stdcall PH_CreateRemoteThread(HANDLE hProcess, LPSECURITY_ATTRIBUTES lpThreadAttributes, DWORD dwStackSize, LPTHREAD_START_ROUTINE lpStartAddress, LPVOID lpParameter, DWORD dwCreationFlags, LPDWORD lpThreadId);
  HANDLE __stdcall PH_OpenThread(DWORD dwDesiredAccess, BOOL bInheritHandle, DWORD dwThreadId);
#ifdef __cplusplus
}
#endif

#ifdef _MSC_VER
#pragma comment(lib, "PrcHelp/PrcHelp_COFF.lib")
#endif
#ifdef __TURBOC__
#pragma comment(lib, "PrcHelp_OMF_B.lib")
#endif
#ifdef __SC__
#pragma comment(lib, "PrcHelp_OMF.lib")
#endif
#ifdef __WATCOMC__
#pragma comment(lib, "PrcHelp_OMF.lib")
#endif

#endif //_PRCHELP_
