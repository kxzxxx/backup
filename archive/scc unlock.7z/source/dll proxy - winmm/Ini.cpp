#include <stdio.h>
#include <string.h>


static char line[1024];
static char temp[1024];



char skip_exe1[512];
char skip_exe2[512];
char skip_exe3[512];
char skip_exe4[512];
char skip_exe5[512];
char skip_exe6[512];
char skip_exe7[512];
char skip_exe8[512];
char skip_exe9[512];



// ############################################### //
// ############################################### //
// ############################################### //
// ############################################### //



void ReadIni()
{
	FILE *fp;


	fp = fopen( "winmm.ini", "r" );
	if( !fp ) return;



	while(1)
	{
		if( feof(fp) ) break;


		fgets( line, 1024, fp );



#define CHECK_ARG_STR(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%s", &y ); \
		continue; \
	}



#define CHECK_ARG(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%d", &y ); \
		continue; \
	}



#define CHECK_ARG_F(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%f", &y ); \
		continue; \
	}



#define CHECK_ARG_F_100(x,y) \
	if( strstr( line,x ) == line ) \
	{ \
		sscanf( line + strlen(x), "%f", &temp_f ); \
		temp_f = temp_f * 100.0f; \
		y = (int) temp_f; \
		continue; \
	}




		float temp_f;



		//CHECK_ARG( "debug log =", ini_debug_log );


		CHECK_ARG_STR( "exe1 =", temp ); if( temp[0] ) sprintf( skip_exe1, "\\%s", temp );
		CHECK_ARG_STR( "exe2 =", temp ); if( temp[0] ) sprintf( skip_exe2, "\\%s", temp );
		CHECK_ARG_STR( "exe3 =", temp ); if( temp[0] ) sprintf( skip_exe3, "\\%s", temp );
		CHECK_ARG_STR( "exe4 =", temp ); if( temp[0] ) sprintf( skip_exe4, "\\%s", temp );
		CHECK_ARG_STR( "exe5 =", temp ); if( temp[0] ) sprintf( skip_exe5, "\\%s", temp );
		CHECK_ARG_STR( "exe6 =", temp ); if( temp[0] ) sprintf( skip_exe6, "\\%s", temp );
		CHECK_ARG_STR( "exe7 =", temp ); if( temp[0] ) sprintf( skip_exe7, "\\%s", temp );
		CHECK_ARG_STR( "exe8 =", temp ); if( temp[0] ) sprintf( skip_exe8, "\\%s", temp );
		CHECK_ARG_STR( "exe9 =", temp ); if( temp[0] ) sprintf( skip_exe9, "\\%s", temp );
	}




	fclose(fp);
}
