extern void Load_Asi( char *path, char *ext );

