#pragma comment( lib, "winmm.lib" )




#define DLL_1     waveOutBreakLoop
#define DLL_2     waveOutClose
#define DLL_3     waveOutGetDevCapsA
#define DLL_4     waveOutGetDevCapsW
#define DLL_5     waveOutGetErrorTextA
#define DLL_6     waveOutGetErrorTextW
#define DLL_7     waveOutGetID
#define DLL_8     waveOutGetNumDevs
#define DLL_9     waveOutGetPitch

#define DLL_10    waveOutGetPlaybackRate
#define DLL_11    waveOutGetPosition
#define DLL_12    waveOutGetVolume
#define DLL_13    waveOutMessage
#define DLL_14    waveOutOpen
#define DLL_15    waveOutPause
#define DLL_16    waveOutPrepareHeader
#define DLL_17    waveOutReset
#define DLL_18    waveOutRestart
#define DLL_19    waveOutSetPitch

#define DLL_20    waveOutSetPlaybackRate
#define DLL_21    waveOutSetVolume
#define DLL_22    waveOutUnprepareHeader
#define DLL_23    waveOutWrite
#define DLL_24    DLL_24
#define DLL_25    DLL_25
#define DLL_26    DLL_26
#define DLL_27    DLL_27
#define DLL_28    DLL_28
#define DLL_29    DLL_29

#define DLL_30    PlaySound
#define DLL_31    PlaySoundA
#define DLL_32    PlaySoundW
#define DLL_33    DLL_33
#define DLL_34    DLL_34
#define DLL_35    DLL_35
#define DLL_36    DLL_36
#define DLL_37    DLL_37
#define DLL_38    DLL_38
#define DLL_39    DLL_39

#define DLL_40    auxGetDevCapsA
#define DLL_41    auxGetDevCapsW
#define DLL_42    auxGetNumDevs
#define DLL_43    auxGetVolume
#define DLL_44    auxOutMessage
#define DLL_45    auxSetVolume
#define DLL_46    aux32Message
#define DLL_47    DLL_47
#define DLL_48    DLL_48
#define DLL_49    DLL_49

#define DLL_50    midiOutClose
#define DLL_51    midiOutGetDevCapsA
#define DLL_52    midiOutGetDevCapsW
#define DLL_53    midiOutGetNumDevs
#define DLL_54    midiOutLongMsg
#define DLL_55    midiOutOpen
#define DLL_56    midiOutPrepareHeader
#define DLL_57    midiOutReset
#define DLL_58    midiOutSetVolume
#define DLL_59    midiOutShortMsg

#define DLL_60    midiOutUnprepareHeader
#define DLL_61    midiOutCacheDrumPatches
#define DLL_62    midiOutCachePatches
#define DLL_63    midiOutGetErrorTextA
#define DLL_64    midiOutGetErrorTextW
#define DLL_65    midiOutGetID
#define DLL_66    midiOutGetVolume
#define DLL_67    midiOutMessage
#define DLL_68    DLL_68
#define DLL_69    DLL_69

#define DLL_70    mciDriverNotify
#define DLL_71    mciDriverYield
#define DLL_72    mciExecute
#define DLL_73    mciFreeCommandResource
#define DLL_74    mciGetCreatorTask
#define DLL_75    mciGetDeviceIDA
#define DLL_76    mciGetDeviceIDW
#define DLL_77    mciGetDeviceIDFromElementIDA
#define DLL_78    mciGetDeviceIDFromElementIDW
#define DLL_79    mciGetDriverData

#define DLL_80    mciGetErrorStringA
#define DLL_81    mciGetErrorStringW
#define DLL_82    mciGetYieldProc
#define DLL_83    mciLoadCommandResource
#define DLL_84    mciSendCommandA
#define DLL_85    mciSendCommandW
#define DLL_86    mciSendStringA
#define DLL_87    mciSendStringW
#define DLL_88    mciSetDriverData
#define DLL_89    mciSetYieldProc

#define DLL_90    mci32Message
#define DLL_91    DLL_91
#define DLL_92    DLL_92
#define DLL_93    DLL_93
#define DLL_94    DLL_94
#define DLL_95    DLL_95
#define DLL_96    DLL_96
#define DLL_97    DLL_97
#define DLL_98    DLL_98
#define DLL_99    DLL_99

#define DLL_100   midiInClose
#define DLL_101   midiInGetDevCapsA
#define DLL_102   midiInGetDevCapsW
#define DLL_103   midiInGetErrorTextA
#define DLL_104   midiInGetErrorTextW
#define DLL_105   midiInGetNumDevs
#define DLL_106   midiInOpen
#define DLL_107   midiInStart
#define DLL_108   midiInReset
#define DLL_109   midiInStop

#define DLL_110   midiInMessage
#define DLL_111   midiInAddBuffer
#define DLL_112   midiInGetID
#define DLL_113   midiInPrepareHeader
#define DLL_114   midiInUnprepareHeader
#define DLL_115   DLL_115
#define DLL_116   DLL_116
#define DLL_117   DLL_117
#define DLL_118   DLL_118
#define DLL_119   DLL_119

#define DLL_120   waveInAddBuffer
#define DLL_121   waveInClose
#define DLL_122   waveInGetDevCapsA
#define DLL_123   waveInGetDevCapsW
#define DLL_124   waveInGetErrorTextA
#define DLL_125   waveInGetErrorTextW
#define DLL_126   waveInGetID
#define DLL_127   waveInGetNumDevs
#define DLL_128   waveInGetPosition
#define DLL_129   waveInMessage

#define DLL_130   waveInOpen
#define DLL_131   waveInPrepareHeader
#define DLL_132   waveInReset
#define DLL_133   waveInStart
#define DLL_134   waveInStop
#define DLL_135   waveInUnprepareHeader
#define DLL_136   DLL_136
#define DLL_137   DLL_137
#define DLL_138   DLL_138
#define DLL_139   DLL_139

#define DLL_140   mixerClose
#define DLL_141   mixerGetControlDetailsA
#define DLL_142   mixerGetControlDetailsW
#define DLL_143   mixerGetDevCapsA
#define DLL_144   mixerGetDevCapsW
#define DLL_145   mixerGetID
#define DLL_146   mixerGetLineControlsA
#define DLL_147   mixerGetLineControlsW
#define DLL_148   mixerGetLineInfoA
#define DLL_149   mixerGetLineInfoW

#define DLL_150   mixerGetNumDevs
#define DLL_151   mixerMessage
#define DLL_152   mixerOpen
#define DLL_153   mixerSetControlDetails
#define DLL_154   DLL_154
#define DLL_155   DLL_155
#define DLL_156   DLL_156
#define DLL_157   DLL_157
#define DLL_158   DLL_158
#define DLL_159   DLL_159

#define DLL_160   timeBeginPeriod
#define DLL_161   timeEndPeriod
#define DLL_162   timeGetSystemTime
#define DLL_163   timeGetTime
#define DLL_164   timeKillEvent
#define DLL_165   timeSetEvent
#define DLL_166   tid32Message
#define DLL_167   timeGetDevCaps
#define DLL_168   DLL_168
#define DLL_169   DLL_169

#define DLL_170   mmioAdvance
#define DLL_171   mmioAscend
#define DLL_172   mmioClose
#define DLL_173   mmioCreateChunk
#define DLL_174   mmioDescend
#define DLL_175   mmioFlush
#define DLL_176   mmioGetInfo
#define DLL_177   mmioInstallOProcA
#define DLL_178   mmioInstallOProcW
#define DLL_179   mmioOpenA

#define DLL_180   mmioOpenW
#define DLL_181   mmioRead
#define DLL_182   mmioRenameA
#define DLL_183   mmioRenameW
#define DLL_184   mmioSeek
#define DLL_185   mmioSendMessage
#define DLL_186   mmioSetBuffer
#define DLL_187   mmioSetInfo
#define DLL_188   mmioStringToFOURCCA
#define DLL_189   mmioStringToFOURCCW

#define DLL_190   mmioWrite
#define DLL_191   DLL_191
#define DLL_192   DLL_192
#define DLL_193   DLL_193
#define DLL_194   DLL_194
#define DLL_195   DLL_195
#define DLL_196   DLL_196
#define DLL_197   DLL_197
#define DLL_198   DLL_198
#define DLL_199   DLL_199

#define DLL_200   mmsystemGetVersion
#define DLL_201   sndPlaySoundA
#define DLL_202   sndPlaySoundW
#define DLL_203   mod32Message
#define DLL_204   msx32Message
#define DLL_205   wid32Message
#define DLL_206   wod32Message
#define DLL_207   DLL_207
#define DLL_208   DLL_208
#define DLL_209   DLL_209

#define DLL_210   CloseDriver
#define DLL_211   DefDriverProc
#define DLL_212   DriverCallback
#define DLL_213   DrvGetModuleHandle
#define DLL_214   GetDriverModuleHandle
#define DLL_215   MigrateAllDrivers
#define DLL_216   MigrateSoundEvents
#define DLL_217   NotifyCallbackData
#define DLL_218   OpenDriver
#define DLL_219   SendDriverMessage

#define DLL_220   WOW32DriverCallback
#define DLL_221   WOW32ResolveMultiMediaHandle
#define DLL_222   WOWAppExit
#define DLL_223   WinmmLogoff
#define DLL_224   WinmmLogon
#define DLL_225   DLL_225
#define DLL_226   DLL_226
#define DLL_227   DLL_227
#define DLL_228   DLL_228
#define DLL_229   DLL_229

#define DLL_230   winmmDbgOut
#define DLL_231   winmmSetDebugLevel
#define DLL_232   DLL_232
#define DLL_233   DLL_233
#define DLL_234   DLL_234
#define DLL_235   DLL_235
#define DLL_236   DLL_236
#define DLL_237   DLL_237
#define DLL_238   DLL_238
#define DLL_239   DLL_239

#define DLL_240   joyConfigChanged
#define DLL_241   joyGetDevCapsA
#define DLL_242   joyGetDevCapsW
#define DLL_243   joyGetNumDevs
#define DLL_244   joyGetPos
#define DLL_245   joyGetPosEx
#define DLL_246   joyGetThreshold
#define DLL_247   joyReleaseCapture
#define DLL_248   joySetCapture
#define DLL_249   joySetThreshold

#define DLL_250   joy32Message
#define DLL_251   DLL_251
#define DLL_252   DLL_252
#define DLL_253   DLL_253
#define DLL_254   DLL_254
#define DLL_255   DLL_255
#define DLL_256   DLL_256
#define DLL_257   DLL_257
#define DLL_258   DLL_258
#define DLL_259   DLL_259

#define DLL_260   mid32Message
#define DLL_261   midiConnect
#define DLL_262   midiDisconnect
#define DLL_263   DLL_263
#define DLL_264   DLL_264
#define DLL_265   DLL_265
#define DLL_266   DLL_266
#define DLL_267   DLL_267
#define DLL_268   DLL_268
#define DLL_269   DLL_269

#define DLL_270   midiStreamClose
#define DLL_271   midiStreamOpen
#define DLL_272   midiStreamOut
#define DLL_273   midiStreamPause
#define DLL_274   midiStreamPosition
#define DLL_275   midiStreamProperty
#define DLL_276   midiStreamRestart
#define DLL_277   midiStreamStop
#define DLL_278   DLL_278
#define DLL_279   DLL_279

#define DLL_280   mmDrvInstall
#define DLL_281   mmGetCurrentTask
#define DLL_282   mmTaskBlock
#define DLL_283   mmTaskCreate
#define DLL_284   mmTaskSignal
#define DLL_285   mmTaskYield
#define DLL_286   DLL_286
#define DLL_287   DLL_287
#define DLL_288   DLL_288
#define DLL_289   DLL_289

#define DLL_290   DLL_290
#define DLL_291   DLL_291
#define DLL_292   DLL_292
#define DLL_293   DLL_293
#define DLL_294   DLL_294
#define DLL_295   DLL_295
#define DLL_296   DLL_296
#define DLL_297   DLL_297
#define DLL_298   DLL_298
#define DLL_299   DLL_299







static UINT32 *api_1;
static UINT32 *api_2;
static UINT32 *api_3;
static UINT32 *api_4;
static UINT32 *api_5;
static UINT32 *api_6;
static UINT32 *api_7;
static UINT32 *api_8;
static UINT32 *api_9;

static UINT32 *api_10;
static UINT32 *api_11;
static UINT32 *api_12;
static UINT32 *api_13;
static UINT32 *api_14;
static UINT32 *api_15;
static UINT32 *api_16;
static UINT32 *api_17;
static UINT32 *api_18;
static UINT32 *api_19;

static UINT32 *api_20;
static UINT32 *api_21;
static UINT32 *api_22;
static UINT32 *api_23;
static UINT32 *api_24;
static UINT32 *api_25;
static UINT32 *api_26;
static UINT32 *api_27;
static UINT32 *api_28;
static UINT32 *api_29;

static UINT32 *api_30;
static UINT32 *api_31;
static UINT32 *api_32;
static UINT32 *api_33;
static UINT32 *api_34;
static UINT32 *api_35;
static UINT32 *api_36;
static UINT32 *api_37;
static UINT32 *api_38;
static UINT32 *api_39;

static UINT32 *api_40;
static UINT32 *api_41;
static UINT32 *api_42;
static UINT32 *api_43;
static UINT32 *api_44;
static UINT32 *api_45;
static UINT32 *api_46;
static UINT32 *api_47;
static UINT32 *api_48;
static UINT32 *api_49;

static UINT32 *api_50;
static UINT32 *api_51;
static UINT32 *api_52;
static UINT32 *api_53;
static UINT32 *api_54;
static UINT32 *api_55;
static UINT32 *api_56;
static UINT32 *api_57;
static UINT32 *api_58;
static UINT32 *api_59;

static UINT32 *api_60;
static UINT32 *api_61;
static UINT32 *api_62;
static UINT32 *api_63;
static UINT32 *api_64;
static UINT32 *api_65;
static UINT32 *api_66;
static UINT32 *api_67;
static UINT32 *api_68;
static UINT32 *api_69;

static UINT32 *api_70;
static UINT32 *api_71;
static UINT32 *api_72;
static UINT32 *api_73;
static UINT32 *api_74;
static UINT32 *api_75;
static UINT32 *api_76;
static UINT32 *api_77;
static UINT32 *api_78;
static UINT32 *api_79;

static UINT32 *api_80;
static UINT32 *api_81;
static UINT32 *api_82;
static UINT32 *api_83;
static UINT32 *api_84;
static UINT32 *api_85;
static UINT32 *api_86;
static UINT32 *api_87;
static UINT32 *api_88;
static UINT32 *api_89;

static UINT32 *api_90;
static UINT32 *api_91;
static UINT32 *api_92;
static UINT32 *api_93;
static UINT32 *api_94;
static UINT32 *api_95;
static UINT32 *api_96;
static UINT32 *api_97;
static UINT32 *api_98;
static UINT32 *api_99;

static UINT32 *api_100;
static UINT32 *api_101;
static UINT32 *api_102;
static UINT32 *api_103;
static UINT32 *api_104;
static UINT32 *api_105;
static UINT32 *api_106;
static UINT32 *api_107;
static UINT32 *api_108;
static UINT32 *api_109;

static UINT32 *api_110;
static UINT32 *api_111;
static UINT32 *api_112;
static UINT32 *api_113;
static UINT32 *api_114;
static UINT32 *api_115;
static UINT32 *api_116;
static UINT32 *api_117;
static UINT32 *api_118;
static UINT32 *api_119;

static UINT32 *api_120;
static UINT32 *api_121;
static UINT32 *api_122;
static UINT32 *api_123;
static UINT32 *api_124;
static UINT32 *api_125;
static UINT32 *api_126;
static UINT32 *api_127;
static UINT32 *api_128;
static UINT32 *api_129;

static UINT32 *api_130;
static UINT32 *api_131;
static UINT32 *api_132;
static UINT32 *api_133;
static UINT32 *api_134;
static UINT32 *api_135;
static UINT32 *api_136;
static UINT32 *api_137;
static UINT32 *api_138;
static UINT32 *api_139;

static UINT32 *api_140;
static UINT32 *api_141;
static UINT32 *api_142;
static UINT32 *api_143;
static UINT32 *api_144;
static UINT32 *api_145;
static UINT32 *api_146;
static UINT32 *api_147;
static UINT32 *api_148;
static UINT32 *api_149;

static UINT32 *api_150;
static UINT32 *api_151;
static UINT32 *api_152;
static UINT32 *api_153;
static UINT32 *api_154;
static UINT32 *api_155;
static UINT32 *api_156;
static UINT32 *api_157;
static UINT32 *api_158;
static UINT32 *api_159;

static UINT32 *api_160;
static UINT32 *api_161;
static UINT32 *api_162;
static UINT32 *api_163;
static UINT32 *api_164;
static UINT32 *api_165;
static UINT32 *api_166;
static UINT32 *api_167;
static UINT32 *api_168;
static UINT32 *api_169;

static UINT32 *api_170;
static UINT32 *api_171;
static UINT32 *api_172;
static UINT32 *api_173;
static UINT32 *api_174;
static UINT32 *api_175;
static UINT32 *api_176;
static UINT32 *api_177;
static UINT32 *api_178;
static UINT32 *api_179;

static UINT32 *api_180;
static UINT32 *api_181;
static UINT32 *api_182;
static UINT32 *api_183;
static UINT32 *api_184;
static UINT32 *api_185;
static UINT32 *api_186;
static UINT32 *api_187;
static UINT32 *api_188;
static UINT32 *api_189;

static UINT32 *api_190;
static UINT32 *api_191;
static UINT32 *api_192;
static UINT32 *api_193;
static UINT32 *api_194;
static UINT32 *api_195;
static UINT32 *api_196;
static UINT32 *api_197;
static UINT32 *api_198;
static UINT32 *api_199;

static UINT32 *api_200;
static UINT32 *api_201;
static UINT32 *api_202;
static UINT32 *api_203;
static UINT32 *api_204;
static UINT32 *api_205;
static UINT32 *api_206;
static UINT32 *api_207;
static UINT32 *api_208;
static UINT32 *api_209;

static UINT32 *api_210;
static UINT32 *api_211;
static UINT32 *api_212;
static UINT32 *api_213;
static UINT32 *api_214;
static UINT32 *api_215;
static UINT32 *api_216;
static UINT32 *api_217;
static UINT32 *api_218;
static UINT32 *api_219;

static UINT32 *api_220;
static UINT32 *api_221;
static UINT32 *api_222;
static UINT32 *api_223;
static UINT32 *api_224;
static UINT32 *api_225;
static UINT32 *api_226;
static UINT32 *api_227;
static UINT32 *api_228;
static UINT32 *api_229;

static UINT32 *api_230;
static UINT32 *api_231;
static UINT32 *api_232;
static UINT32 *api_233;
static UINT32 *api_234;
static UINT32 *api_235;
static UINT32 *api_236;
static UINT32 *api_237;
static UINT32 *api_238;
static UINT32 *api_239;

static UINT32 *api_240;
static UINT32 *api_241;
static UINT32 *api_242;
static UINT32 *api_243;
static UINT32 *api_244;
static UINT32 *api_245;
static UINT32 *api_246;
static UINT32 *api_247;
static UINT32 *api_248;
static UINT32 *api_249;

static UINT32 *api_250;
static UINT32 *api_251;
static UINT32 *api_252;
static UINT32 *api_253;
static UINT32 *api_254;
static UINT32 *api_255;
static UINT32 *api_256;
static UINT32 *api_257;
static UINT32 *api_258;
static UINT32 *api_259;

static UINT32 *api_260;
static UINT32 *api_261;
static UINT32 *api_262;
static UINT32 *api_263;
static UINT32 *api_264;
static UINT32 *api_265;
static UINT32 *api_266;
static UINT32 *api_267;
static UINT32 *api_268;
static UINT32 *api_269;

static UINT32 *api_270;
static UINT32 *api_271;
static UINT32 *api_272;
static UINT32 *api_273;
static UINT32 *api_274;
static UINT32 *api_275;
static UINT32 *api_276;
static UINT32 *api_277;
static UINT32 *api_278;
static UINT32 *api_279;

static UINT32 *api_280;
static UINT32 *api_281;
static UINT32 *api_282;
static UINT32 *api_283;
static UINT32 *api_284;
static UINT32 *api_285;
static UINT32 *api_286;
static UINT32 *api_287;
static UINT32 *api_288;
static UINT32 *api_289;

static UINT32 *api_290;
static UINT32 *api_291;
static UINT32 *api_292;
static UINT32 *api_293;
static UINT32 *api_294;
static UINT32 *api_295;
static UINT32 *api_296;
static UINT32 *api_297;
static UINT32 *api_298;
static UINT32 *api_299;






static char line[512];



static unsigned char buf[0x800000];
static HMODULE hDll;



// ######################################################### //
// ######################################################### //
// ######################################################### //
// ######################################################### //



static void Copy_Dll( WCHAR *in, WCHAR *out )
{
	WCHAR name[512];


	// Win95 compatibility
	GetSystemDirectoryW( name, 511 );
	wcscat( name, L"\\" );
	wcscat( name, in );



	FILE *fp1, *fp2;
	fp1 = _wfopen( name, L"rb" );
	fp2 = _wfopen( out, L"wb" );


	if( !fp1 ) return;
	if( !fp2 ) return;



	int size;
	size = fread( &buf, 1, 0x800000, fp1 );
	fwrite( &buf, 1, size, fp2 );



	fclose( fp1 );
	fclose( fp2 );
}




static void Reloc_Api()
{
	// already initialized
	if( api_1 ) return;




	Copy_Dll( L"winmm.dll", L"winmm.asi" );




	hDll = LoadLibrary( "winmm.asi" );
	DWORD error = GetLastError();



	// error 1: someone loaded winmm.dll from inside another dllmain?? bad for dll proxy!!
	// error 2: uninitialized dllmain not called yet
	// error 3: dll locker elsewhere

	if( hDll == 0 )
	{
		//fp = fopen( "winmm_failed.txt", "w" );
		//fprintf( fp, "LoadLibrary error = %X", error );
		//fclose( fp );
		return;
	}



	// **************************************************** //
	// **************************************************** //
	// **************************************************** //


#ifdef DEBUG_CALL
	fp = fopen( "api32_logger.txt", "w" );
	fprintf( fp, "api32 functions\n" );
#endif




#define STR(a) #a


#define GETDLL( a,b ) \
	a = (UINT32 *) GetProcAddress( hDll, STR(b) ); \
	if( fp ) fprintf( fp, "%s = %x\n", STR(b), a );





	GETDLL( api_1, DLL_1 )
	GETDLL( api_2, DLL_2 )
	GETDLL( api_3, DLL_3 )
	GETDLL( api_4, DLL_4 )
	GETDLL( api_5, DLL_5 )
	GETDLL( api_6, DLL_6 )
	GETDLL( api_7, DLL_7 )
	GETDLL( api_8, DLL_8 )
	GETDLL( api_9, DLL_9 )

	GETDLL( api_10, DLL_10 )
	GETDLL( api_11, DLL_11 )
	GETDLL( api_12, DLL_12 )
	GETDLL( api_13, DLL_13 )
	GETDLL( api_14, DLL_14 )
	GETDLL( api_15, DLL_15 )
	GETDLL( api_16, DLL_16 )
	GETDLL( api_17, DLL_17 )
	GETDLL( api_18, DLL_18 )
	GETDLL( api_19, DLL_19 )

	GETDLL( api_20, DLL_20 )
	GETDLL( api_21, DLL_21 )
	GETDLL( api_22, DLL_22 )
	GETDLL( api_23, DLL_23 )
	GETDLL( api_24, DLL_24 )
	GETDLL( api_25, DLL_25 )
	GETDLL( api_26, DLL_26 )
	GETDLL( api_27, DLL_27 )
	GETDLL( api_28, DLL_28 )
	GETDLL( api_29, DLL_29 )

	GETDLL( api_30, DLL_30 )
	GETDLL( api_31, DLL_31 )
	GETDLL( api_32, DLL_32 )
	GETDLL( api_33, DLL_33 )
	GETDLL( api_34, DLL_34 )
	GETDLL( api_35, DLL_35 )
	GETDLL( api_36, DLL_36 )
	GETDLL( api_37, DLL_37 )
	GETDLL( api_38, DLL_38 )
	GETDLL( api_39, DLL_39 )

	GETDLL( api_40, DLL_40 )
	GETDLL( api_41, DLL_41 )
	GETDLL( api_42, DLL_42 )
	GETDLL( api_43, DLL_43 )
	GETDLL( api_44, DLL_44 )
	GETDLL( api_45, DLL_45 )
	GETDLL( api_46, DLL_46 )
	GETDLL( api_47, DLL_47 )
	GETDLL( api_48, DLL_48 )
	GETDLL( api_49, DLL_49 )

	GETDLL( api_50, DLL_50 )
	GETDLL( api_51, DLL_51 )
	GETDLL( api_52, DLL_52 )
	GETDLL( api_53, DLL_53 )
	GETDLL( api_54, DLL_54 )
	GETDLL( api_55, DLL_55 )
	GETDLL( api_56, DLL_56 )
	GETDLL( api_57, DLL_57 )
	GETDLL( api_58, DLL_58 )
	GETDLL( api_59, DLL_59 )

	GETDLL( api_60, DLL_60 )
	GETDLL( api_61, DLL_61 )
	GETDLL( api_62, DLL_62 )
	GETDLL( api_63, DLL_63 )
	GETDLL( api_64, DLL_64 )
	GETDLL( api_65, DLL_65 )
	GETDLL( api_66, DLL_66 )
	GETDLL( api_67, DLL_67 )
	GETDLL( api_68, DLL_68 )
	GETDLL( api_69, DLL_69 )

	GETDLL( api_70, DLL_70 )
	GETDLL( api_71, DLL_71 )
	GETDLL( api_72, DLL_72 )
	GETDLL( api_73, DLL_73 )
	GETDLL( api_74, DLL_74 )
	GETDLL( api_75, DLL_75 )
	GETDLL( api_76, DLL_76 )
	GETDLL( api_77, DLL_77 )
	GETDLL( api_78, DLL_78 )
	GETDLL( api_79, DLL_79 )

	GETDLL( api_80, DLL_80 )
	GETDLL( api_81, DLL_81 )
	GETDLL( api_82, DLL_82 )
	GETDLL( api_83, DLL_83 )
	GETDLL( api_84, DLL_84 )
	GETDLL( api_85, DLL_85 )
	GETDLL( api_86, DLL_86 )
	GETDLL( api_87, DLL_87 )
	GETDLL( api_88, DLL_88 )
	GETDLL( api_89, DLL_89 )

	GETDLL( api_90, DLL_90 )
	GETDLL( api_91, DLL_91 )
	GETDLL( api_92, DLL_92 )
	GETDLL( api_93, DLL_93 )
	GETDLL( api_94, DLL_94 )
	GETDLL( api_95, DLL_95 )
	GETDLL( api_96, DLL_96 )
	GETDLL( api_97, DLL_97 )
	GETDLL( api_98, DLL_98 )
	GETDLL( api_99, DLL_99 )

	GETDLL( api_100, DLL_100 )
	GETDLL( api_101, DLL_101 )
	GETDLL( api_102, DLL_102 )
	GETDLL( api_103, DLL_103 )
	GETDLL( api_104, DLL_104 )
	GETDLL( api_105, DLL_105 )
	GETDLL( api_106, DLL_106 )
	GETDLL( api_107, DLL_107 )
	GETDLL( api_108, DLL_108 )
	GETDLL( api_109, DLL_109 )

	GETDLL( api_110, DLL_110 )
	GETDLL( api_111, DLL_111 )
	GETDLL( api_112, DLL_112 )
	GETDLL( api_113, DLL_113 )
	GETDLL( api_114, DLL_114 )
	GETDLL( api_115, DLL_115 )
	GETDLL( api_116, DLL_116 )
	GETDLL( api_117, DLL_117 )
	GETDLL( api_118, DLL_118 )
	GETDLL( api_119, DLL_119 )

	GETDLL( api_120, DLL_120 )
	GETDLL( api_121, DLL_121 )
	GETDLL( api_122, DLL_122 )
	GETDLL( api_123, DLL_123 )
	GETDLL( api_124, DLL_124 )
	GETDLL( api_125, DLL_125 )
	GETDLL( api_126, DLL_126 )
	GETDLL( api_127, DLL_127 )
	GETDLL( api_128, DLL_128 )
	GETDLL( api_129, DLL_129 )

	GETDLL( api_130, DLL_130 )
	GETDLL( api_131, DLL_131 )
	GETDLL( api_132, DLL_132 )
	GETDLL( api_133, DLL_133 )
	GETDLL( api_134, DLL_134 )
	GETDLL( api_135, DLL_135 )
	GETDLL( api_136, DLL_136 )
	GETDLL( api_137, DLL_137 )
	GETDLL( api_138, DLL_138 )
	GETDLL( api_139, DLL_139 )

	GETDLL( api_140, DLL_140 )
	GETDLL( api_141, DLL_141 )
	GETDLL( api_142, DLL_142 )
	GETDLL( api_143, DLL_143 )
	GETDLL( api_144, DLL_144 )
	GETDLL( api_145, DLL_145 )
	GETDLL( api_146, DLL_146 )
	GETDLL( api_147, DLL_147 )
	GETDLL( api_148, DLL_148 )
	GETDLL( api_149, DLL_149 )

	GETDLL( api_150, DLL_150 )
	GETDLL( api_151, DLL_151 )
	GETDLL( api_152, DLL_152 )
	GETDLL( api_153, DLL_153 )
	GETDLL( api_154, DLL_154 )
	GETDLL( api_155, DLL_155 )
	GETDLL( api_156, DLL_156 )
	GETDLL( api_157, DLL_157 )
	GETDLL( api_158, DLL_158 )
	GETDLL( api_159, DLL_159 )

	GETDLL( api_160, DLL_160 )
	GETDLL( api_161, DLL_161 )
	GETDLL( api_162, DLL_162 )
	GETDLL( api_163, DLL_163 )
	GETDLL( api_164, DLL_164 )
	GETDLL( api_165, DLL_165 )
	GETDLL( api_166, DLL_166 )
	GETDLL( api_167, DLL_167 )
	GETDLL( api_168, DLL_168 )
	GETDLL( api_169, DLL_169 )

	GETDLL( api_170, DLL_170 )
	GETDLL( api_171, DLL_171 )
	GETDLL( api_172, DLL_172 )
	GETDLL( api_173, DLL_173 )
	GETDLL( api_174, DLL_174 )
	GETDLL( api_175, DLL_175 )
	GETDLL( api_176, DLL_176 )
	GETDLL( api_177, DLL_177 )
	GETDLL( api_178, DLL_178 )
	GETDLL( api_179, DLL_179 )

	GETDLL( api_180, DLL_180 )
	GETDLL( api_181, DLL_181 )
	GETDLL( api_182, DLL_182 )
	GETDLL( api_183, DLL_183 )
	GETDLL( api_184, DLL_184 )
	GETDLL( api_185, DLL_185 )
	GETDLL( api_186, DLL_186 )
	GETDLL( api_187, DLL_187 )
	GETDLL( api_188, DLL_188 )
	GETDLL( api_189, DLL_189 )

	GETDLL( api_190, DLL_190 )
	GETDLL( api_191, DLL_191 )
	GETDLL( api_192, DLL_192 )
	GETDLL( api_193, DLL_193 )
	GETDLL( api_194, DLL_194 )
	GETDLL( api_195, DLL_195 )
	GETDLL( api_196, DLL_196 )
	GETDLL( api_197, DLL_197 )
	GETDLL( api_198, DLL_198 )
	GETDLL( api_199, DLL_199 )

	GETDLL( api_200, DLL_200 )
	GETDLL( api_201, DLL_201 )
	GETDLL( api_202, DLL_202 )
	GETDLL( api_203, DLL_203 )
	GETDLL( api_204, DLL_204 )
	GETDLL( api_205, DLL_205 )
	GETDLL( api_206, DLL_206 )
	GETDLL( api_207, DLL_207 )
	GETDLL( api_208, DLL_208 )
	GETDLL( api_209, DLL_209 )

	GETDLL( api_210, DLL_210 )
	GETDLL( api_211, DLL_211 )
	GETDLL( api_212, DLL_212 )
	GETDLL( api_213, DLL_213 )
	GETDLL( api_214, DLL_214 )
	GETDLL( api_215, DLL_215 )
	GETDLL( api_216, DLL_216 )
	GETDLL( api_217, DLL_217 )
	GETDLL( api_218, DLL_218 )
	GETDLL( api_219, DLL_219 )

	GETDLL( api_220, DLL_220 )
	GETDLL( api_221, DLL_221 )
	GETDLL( api_222, DLL_222 )
	GETDLL( api_223, DLL_223 )
	GETDLL( api_224, DLL_224 )
	GETDLL( api_225, DLL_225 )
	GETDLL( api_226, DLL_226 )
	GETDLL( api_227, DLL_227 )
	GETDLL( api_228, DLL_228 )
	GETDLL( api_229, DLL_229 )

	GETDLL( api_230, DLL_230 )
	GETDLL( api_231, DLL_231 )
	GETDLL( api_232, DLL_232 )
	GETDLL( api_233, DLL_233 )
	GETDLL( api_234, DLL_234 )
	GETDLL( api_235, DLL_235 )
	GETDLL( api_236, DLL_236 )
	GETDLL( api_237, DLL_237 )
	GETDLL( api_238, DLL_238 )
	GETDLL( api_239, DLL_239 )

	GETDLL( api_240, DLL_240 )
	GETDLL( api_241, DLL_241 )
	GETDLL( api_242, DLL_242 )
	GETDLL( api_243, DLL_243 )
	GETDLL( api_244, DLL_244 )
	GETDLL( api_245, DLL_245 )
	GETDLL( api_246, DLL_246 )
	GETDLL( api_247, DLL_247 )
	GETDLL( api_248, DLL_248 )
	GETDLL( api_249, DLL_249 )

	GETDLL( api_250, DLL_250 )
	GETDLL( api_251, DLL_251 )
	GETDLL( api_252, DLL_252 )
	GETDLL( api_253, DLL_253 )
	GETDLL( api_254, DLL_254 )
	GETDLL( api_255, DLL_255 )
	GETDLL( api_256, DLL_256 )
	GETDLL( api_257, DLL_257 )
	GETDLL( api_258, DLL_258 )
	GETDLL( api_259, DLL_259 )

	GETDLL( api_260, DLL_260 )
	GETDLL( api_261, DLL_261 )
	GETDLL( api_262, DLL_262 )
	GETDLL( api_263, DLL_263 )
	GETDLL( api_264, DLL_264 )
	GETDLL( api_265, DLL_265 )
	GETDLL( api_266, DLL_266 )
	GETDLL( api_267, DLL_267 )
	GETDLL( api_268, DLL_268 )
	GETDLL( api_269, DLL_269 )

	GETDLL( api_270, DLL_270 )
	GETDLL( api_271, DLL_271 )
	GETDLL( api_272, DLL_272 )
	GETDLL( api_273, DLL_273 )
	GETDLL( api_274, DLL_274 )
	GETDLL( api_275, DLL_275 )
	GETDLL( api_276, DLL_276 )
	GETDLL( api_277, DLL_277 )
	GETDLL( api_278, DLL_278 )
	GETDLL( api_279, DLL_279 )

	GETDLL( api_280, DLL_280 )
	GETDLL( api_281, DLL_281 )
	GETDLL( api_282, DLL_282 )
	GETDLL( api_283, DLL_283 )
	GETDLL( api_284, DLL_284 )
	GETDLL( api_285, DLL_285 )
	GETDLL( api_286, DLL_286 )
	GETDLL( api_287, DLL_287 )
	GETDLL( api_288, DLL_288 )
	GETDLL( api_289, DLL_289 )

	GETDLL( api_290, DLL_290 )
	GETDLL( api_291, DLL_291 )
	GETDLL( api_292, DLL_292 )
	GETDLL( api_293, DLL_293 )
	GETDLL( api_294, DLL_294 )
	GETDLL( api_295, DLL_295 )
	GETDLL( api_296, DLL_296 )
	GETDLL( api_297, DLL_297 )
	GETDLL( api_298, DLL_298 )
	GETDLL( api_299, DLL_299 )




#ifdef DEBUG_CALL
	fflush( fp );
	fclose( fp );
#endif

}




int log_arg1;


void Log_Call()
{
#ifdef DEBUG_CALL
	fprintf( fp, "%d\n", log_arg1 );
	fflush( fp );
#endif
}




#ifdef DEBUG_CALL



#define FUNC0(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y(void) \
{ \
	__asm pushad \
	__asm pushfd \
	\
	__asm call Init \
	\
	__asm mov log_arg1, x \
	__asm call Log_Call \
	\
	__asm popfd \
	__asm popad \
	\
	\
	__asm push api_##x \
	__asm ret \
}




#define FUNC4(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y( INT32 a1 ) \
{ \
	__asm pushad \
	__asm pushfd \
	\
	__asm call Init \
	\
	__asm mov log_arg1, x \
	__asm call Log_Call \
	\
	__asm popfd \
	__asm popad \
	\
	\
	__asm push api_##x \
	__asm ret \
}




#define FUNC8(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y( INT64 a1 ) \
{ \
	\
	__asm pushad \
	__asm pushfd \
	\
	__asm call Init \
	\
	__asm mov log_arg1, x \
	__asm call Log_Call \
	\
	__asm popfd \
	__asm popad \
	\
	\
	__asm push api_##x \
	__asm ret \
}




#define FUNC12(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT32 a2 ) \
{ \
	\
	__asm pushad \
	__asm pushfd \
	\
	__asm call Init \
	\
	__asm mov log_arg1, x \
	__asm call Log_Call \
	\
	__asm popfd \
	__asm popad \
	\
	\
	__asm push api_##x \
	__asm ret \
}




#define FUNC16(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT64 a2 ) \
{ \
	\
	__asm pushad \
	__asm pushfd \
	\
	__asm call Init \
	\
	__asm mov log_arg1, x \
	__asm call Log_Call \
	\
	__asm popfd \
	__asm popad \
	\
	\
	__asm push api_##x \
	__asm ret \
}




#define FUNC20(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT64 a2, INT32 a3 ) \
{ \
	\
	__asm pushad \
	__asm pushfd \
	\
	__asm call Init \
	\
	__asm mov log_arg1, x \
	__asm call Log_Call \
	\
	__asm popfd \
	__asm popad \
	\
	\
	__asm push api_##x \
	__asm ret \
}




#define FUNC24(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT64 a2, INT64 a3 ) \
{ \
	\
	__asm pushad \
	__asm pushfd \
	\
	__asm call Init \
	\
	__asm mov log_arg1, x \
	__asm call Log_Call \
	\
	__asm popfd \
	__asm popad \
	\
	\
	__asm push api_##x \
	__asm ret \
}




#define FUNC28(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT64 a2, INT64 a3, INT32 a4 ) \
{ \
	\
	__asm pushad \
	__asm pushfd \
	\
	__asm call Init \
	\
	__asm mov log_arg1, x \
	__asm call Log_Call \
	\
	__asm popfd \
	__asm popad \
	\
	\
	__asm push api_##x \
	__asm ret \
}




#define FUNC44(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT64 a2, INT64 a3, INT64 a4, INT64 a5, INT32 a6 ) \
{ \
	\
	__asm pushad \
	__asm pushfd \
	\
	__asm call Init \
	\
	__asm mov log_arg1, x \
	__asm call Log_Call \
	\
	__asm popfd \
	__asm popad \
	\
	\
	__asm push api_##x \
	__asm ret \
}



#else



#if 1


#define FUNC0(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y( void ) \
{ \
	__asm cmp api_1, 0 \
	__asm jne done \
\
\
	__asm pushad \
	__asm pushfd \
\
	__asm call Reloc_Api \
\
	__asm popfd \
	__asm popad \
\
\
	__asm done: \
	__asm push api_##x \
	__asm ret \
}


#else


#define FUNC0(x,y) \
\
extern "C" void __declspec(dllexport) __declspec(naked) y( void ) \
{ \
	__asm push api_##x \
	__asm ret \
}


#endif



#define FUNC4(x,y) \
\
void __declspec(dllexport) __declspec(naked) y( INT32 a1 ) \
{ \
	__asm push api_##x \
	__asm ret \
}




#define FUNC8(x,y) \
\
void __declspec(dllexport) __declspec(naked) y( INT64 a1 ) \
{ \
	__asm push api_##x \
	__asm ret \
}




#define FUNC12(x,y) \
\
void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT32 a2 ) \
{ \
	__asm push api_##x \
	__asm ret \
}




#define FUNC16(x,y) \
\
void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT64 a2 ) \
{ \
	__asm push api_##x \
	__asm ret \
}




#define FUNC20(x,y) \
\
void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT64 a2, INT32 a3 ) \
{ \
	__asm push api_##x \
	__asm ret \
}




#define FUNC24(x,y) \
\
void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT64 a2, INT64 a3 ) \
{ \
	__asm push api_##x \
	__asm ret \
}




#define FUNC28(x,y) \
\
void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT64 a2, INT64 a3, INT32 a4 ) \
{ \
	__asm push api_##x \
	__asm ret \
}




#define FUNC44(x,y) \
\
void __declspec(dllexport) __declspec(naked) y( INT64 a1, INT64 a2, INT64 a3, INT64 a4, INT64 a5, INT32 a6 ) \
{ \
	__asm push api_##x \
	__asm ret \
}



#endif




FUNC0( 1, DLL_1 )
FUNC0( 2, DLL_2 )
FUNC0( 3, DLL_3 )
FUNC0( 4, DLL_4 )
FUNC0( 5, DLL_5 )
FUNC0( 6, DLL_6 )
FUNC0( 7, DLL_7 )
FUNC0( 8, DLL_8 )
FUNC0( 9, DLL_9 )

FUNC0( 10, DLL_10 )
FUNC0( 11, DLL_11 )
FUNC0( 12, DLL_12 )
FUNC0( 13, DLL_13 )
FUNC0( 14, DLL_14 )
FUNC0( 15, DLL_15 )
FUNC0( 16, DLL_16 )
FUNC0( 17, DLL_17 )
FUNC0( 18, DLL_18 )
FUNC0( 19, DLL_19 )

FUNC0( 20, DLL_20 )
FUNC0( 21, DLL_21 )
FUNC0( 22, DLL_22 )
FUNC0( 23, DLL_23 )
FUNC0( 24, DLL_24 )
FUNC0( 25, DLL_25 )
FUNC0( 26, DLL_26 )
FUNC0( 27, DLL_27 )
FUNC0( 28, DLL_28 )
FUNC0( 29, DLL_29 )

FUNC0( 30, DLL_30 )
FUNC0( 31, DLL_31 )
FUNC0( 32, DLL_32 )
FUNC0( 33, DLL_33 )
FUNC0( 34, DLL_34 )
FUNC0( 35, DLL_35 )
FUNC0( 36, DLL_36 )
FUNC0( 37, DLL_37 )
FUNC0( 38, DLL_38 )
FUNC0( 39, DLL_39 )

FUNC0( 40, DLL_40 )
FUNC0( 41, DLL_41 )
FUNC0( 42, DLL_42 )
FUNC0( 43, DLL_43 )
FUNC0( 44, DLL_44 )
FUNC0( 45, DLL_45 )
FUNC0( 46, DLL_46 )
FUNC0( 47, DLL_47 )
FUNC0( 48, DLL_48 )
FUNC0( 49, DLL_49 )

FUNC0( 50, DLL_50 )
FUNC0( 51, DLL_51 )
FUNC0( 52, DLL_52 )
FUNC0( 53, DLL_53 )
FUNC0( 54, DLL_54 )
FUNC0( 55, DLL_55 )
FUNC0( 56, DLL_56 )
FUNC0( 57, DLL_57 )
FUNC0( 58, DLL_58 )
FUNC0( 59, DLL_59 )

FUNC0( 60, DLL_60 )
FUNC0( 61, DLL_61 )
FUNC0( 62, DLL_62 )
FUNC0( 63, DLL_63 )
FUNC0( 64, DLL_64 )
FUNC0( 65, DLL_65 )
FUNC0( 66, DLL_66 )
FUNC0( 67, DLL_67 )
FUNC0( 68, DLL_68 )
FUNC0( 69, DLL_69 )

FUNC0( 70, DLL_70 )
FUNC0( 71, DLL_71 )
FUNC0( 72, DLL_72 )
FUNC0( 73, DLL_73 )
FUNC0( 74, DLL_74 )
FUNC0( 75, DLL_75 )
FUNC0( 76, DLL_76 )
FUNC0( 77, DLL_77 )
FUNC0( 78, DLL_78 )
FUNC0( 79, DLL_79 )

FUNC0( 80, DLL_80 )
FUNC0( 81, DLL_81 )
FUNC0( 82, DLL_82 )
FUNC0( 83, DLL_83 )
FUNC0( 84, DLL_84 )
FUNC0( 85, DLL_85 )
FUNC0( 86, DLL_86 )
FUNC0( 87, DLL_87 )
FUNC0( 88, DLL_88 )
FUNC0( 89, DLL_89 )

FUNC0( 90, DLL_90 )
FUNC0( 91, DLL_91 )
FUNC0( 92, DLL_92 )
FUNC0( 93, DLL_93 )
FUNC0( 94, DLL_94 )
FUNC0( 95, DLL_95 )
FUNC0( 96, DLL_96 )
FUNC0( 97, DLL_97 )
FUNC0( 98, DLL_98 )
FUNC0( 99, DLL_99 )

FUNC0( 100, DLL_100 )
FUNC0( 101, DLL_101 )
FUNC0( 102, DLL_102 )
FUNC0( 103, DLL_103 )
FUNC0( 104, DLL_104 )
FUNC0( 105, DLL_105 )
FUNC0( 106, DLL_106 )
FUNC0( 107, DLL_107 )
FUNC0( 108, DLL_108 )
FUNC0( 109, DLL_109 )

FUNC0( 110, DLL_110 )
FUNC0( 111, DLL_111 )
FUNC0( 112, DLL_112 )
FUNC0( 113, DLL_113 )
FUNC0( 114, DLL_114 )
FUNC0( 115, DLL_115 )
FUNC0( 116, DLL_116 )
FUNC0( 117, DLL_117 )
FUNC0( 118, DLL_118 )
FUNC0( 119, DLL_119 )

FUNC0( 120, DLL_120 )
FUNC0( 121, DLL_121 )
FUNC0( 122, DLL_122 )
FUNC0( 123, DLL_123 )
FUNC0( 124, DLL_124 )
FUNC0( 125, DLL_125 )
FUNC0( 126, DLL_126 )
FUNC0( 127, DLL_127 )
FUNC0( 128, DLL_128 )
FUNC0( 129, DLL_129 )

FUNC0( 130, DLL_130 )
FUNC0( 131, DLL_131 )
FUNC0( 132, DLL_132 )
FUNC0( 133, DLL_133 )
FUNC0( 134, DLL_134 )
FUNC0( 135, DLL_135 )
FUNC0( 136, DLL_136 )
FUNC0( 137, DLL_137 )
FUNC0( 138, DLL_138 )
FUNC0( 139, DLL_139 )

FUNC0( 140, DLL_140 )
FUNC0( 141, DLL_141 )
FUNC0( 142, DLL_142 )
FUNC0( 143, DLL_143 )
FUNC0( 144, DLL_144 )
FUNC0( 145, DLL_145 )
FUNC0( 146, DLL_146 )
FUNC0( 147, DLL_147 )
FUNC0( 148, DLL_148 )
FUNC0( 149, DLL_149 )

FUNC0( 150, DLL_150 )
FUNC0( 151, DLL_151 )
FUNC0( 152, DLL_152 )
FUNC0( 153, DLL_153 )
FUNC0( 154, DLL_154 )
FUNC0( 155, DLL_155 )
FUNC0( 156, DLL_156 )
FUNC0( 157, DLL_157 )
FUNC0( 158, DLL_158 )
FUNC0( 159, DLL_159 )

FUNC0( 160, DLL_160 )
FUNC0( 161, DLL_161 )
FUNC0( 162, DLL_162 )
FUNC0( 163, DLL_163 )
FUNC0( 164, DLL_164 )
FUNC0( 165, DLL_165 )
FUNC0( 166, DLL_166 )
FUNC0( 167, DLL_167 )
FUNC0( 168, DLL_168 )
FUNC0( 169, DLL_169 )

FUNC0( 170, DLL_170 )
FUNC0( 171, DLL_171 )
FUNC0( 172, DLL_172 )
FUNC0( 173, DLL_173 )
FUNC0( 174, DLL_174 )
FUNC0( 175, DLL_175 )
FUNC0( 176, DLL_176 )
FUNC0( 177, DLL_177 )
FUNC0( 178, DLL_178 )
FUNC0( 179, DLL_179 )

FUNC0( 180, DLL_180 )
FUNC0( 181, DLL_181 )
FUNC0( 182, DLL_182 )
FUNC0( 183, DLL_183 )
FUNC0( 184, DLL_184 )
FUNC0( 185, DLL_185 )
FUNC0( 186, DLL_186 )
FUNC0( 187, DLL_187 )
FUNC0( 188, DLL_188 )
FUNC0( 189, DLL_189 )

FUNC0( 190, DLL_190 )
FUNC0( 191, DLL_191 )
FUNC0( 192, DLL_192 )
FUNC0( 193, DLL_193 )
FUNC0( 194, DLL_194 )
FUNC0( 195, DLL_195 )
FUNC0( 196, DLL_196 )
FUNC0( 197, DLL_197 )
FUNC0( 198, DLL_198 )
FUNC0( 199, DLL_199 )

FUNC0( 200, DLL_200 )
FUNC0( 201, DLL_201 )
FUNC0( 202, DLL_202 )
FUNC0( 203, DLL_203 )
FUNC0( 204, DLL_204 )
FUNC0( 205, DLL_205 )
FUNC0( 206, DLL_206 )
FUNC0( 207, DLL_207 )
FUNC0( 208, DLL_208 )
FUNC0( 209, DLL_209 )

FUNC0( 210, DLL_210 )
FUNC0( 211, DLL_211 )
FUNC0( 212, DLL_212 )
FUNC0( 213, DLL_213 )
FUNC0( 214, DLL_214 )
FUNC0( 215, DLL_215 )
FUNC0( 216, DLL_216 )
FUNC0( 217, DLL_217 )
FUNC0( 218, DLL_218 )
FUNC0( 219, DLL_219 )

FUNC0( 220, DLL_220 )
FUNC0( 221, DLL_221 )
FUNC0( 222, DLL_222 )
FUNC0( 223, DLL_223 )
FUNC0( 224, DLL_224 )
FUNC0( 225, DLL_225 )
FUNC0( 226, DLL_226 )
FUNC0( 227, DLL_227 )
FUNC0( 228, DLL_228 )
FUNC0( 229, DLL_229 )

FUNC0( 230, DLL_230 )
FUNC0( 231, DLL_231 )
FUNC0( 232, DLL_232 )
FUNC0( 233, DLL_233 )
FUNC0( 234, DLL_234 )
FUNC0( 235, DLL_235 )
FUNC0( 236, DLL_236 )
FUNC0( 237, DLL_237 )
FUNC0( 238, DLL_238 )
FUNC0( 239, DLL_239 )

FUNC0( 240, DLL_240 )
FUNC0( 241, DLL_241 )
FUNC0( 242, DLL_242 )
FUNC0( 243, DLL_243 )
FUNC0( 244, DLL_244 )
FUNC0( 245, DLL_245 )
FUNC0( 246, DLL_246 )
FUNC0( 247, DLL_247 )
FUNC0( 248, DLL_248 )
FUNC0( 249, DLL_249 )

FUNC0( 250, DLL_250 )
FUNC0( 251, DLL_251 )
FUNC0( 252, DLL_252 )
FUNC0( 253, DLL_253 )
FUNC0( 254, DLL_254 )
FUNC0( 255, DLL_255 )
FUNC0( 256, DLL_256 )
FUNC0( 257, DLL_257 )
FUNC0( 258, DLL_258 )
FUNC0( 259, DLL_259 )

FUNC0( 260, DLL_260 )
FUNC0( 261, DLL_261 )
FUNC0( 262, DLL_262 )
FUNC0( 263, DLL_263 )
FUNC0( 264, DLL_264 )
FUNC0( 265, DLL_265 )
FUNC0( 266, DLL_266 )
FUNC0( 267, DLL_267 )
FUNC0( 268, DLL_268 )
FUNC0( 269, DLL_269 )

FUNC0( 270, DLL_270 )
FUNC0( 271, DLL_271 )
FUNC0( 272, DLL_272 )
FUNC0( 273, DLL_273 )
FUNC0( 274, DLL_274 )
FUNC0( 275, DLL_275 )
FUNC0( 276, DLL_276 )
FUNC0( 277, DLL_277 )
FUNC0( 278, DLL_278 )
FUNC0( 279, DLL_279 )

FUNC0( 280, DLL_280 )
FUNC0( 281, DLL_281 )
FUNC0( 282, DLL_282 )
FUNC0( 283, DLL_283 )
FUNC0( 284, DLL_284 )
FUNC0( 285, DLL_285 )
FUNC0( 286, DLL_286 )
FUNC0( 287, DLL_287 )
FUNC0( 288, DLL_288 )
FUNC0( 289, DLL_289 )

FUNC0( 290, DLL_290 )
FUNC0( 291, DLL_291 )
FUNC0( 292, DLL_292 )
FUNC0( 293, DLL_293 )
FUNC0( 294, DLL_294 )
FUNC0( 295, DLL_295 )
FUNC0( 296, DLL_296 )
FUNC0( 297, DLL_297 )
FUNC0( 298, DLL_298 )
FUNC0( 299, DLL_299 )
