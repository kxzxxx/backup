#include <windows.h>

#include "DllLock.h"




DllLock::DllLock( CRITICAL_SECTION* cs ) : cs_(cs)
{
	EnterCriticalSection( cs_ );
}



DllLock::~DllLock()
{
	LeaveCriticalSection( cs_ );
}
