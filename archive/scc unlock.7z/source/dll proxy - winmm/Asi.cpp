#include "windows.h"




void Load_Asi( char *path, char *ext )
{
	WIN32_FIND_DATA ffd;
	HANDLE hFind = INVALID_HANDLE_VALUE;



	char fullName[512];

	strcpy( fullName, path );
	strcat( fullName, "\\" );
	strcat( fullName, ext );
	



	// Find the first file in the directory.
	hFind = FindFirstFile( fullName, &ffd );
	if( INVALID_HANDLE_VALUE == hFind ) return;

	

	// List all the files in the directory with some info about them.
	do
	{
		if( ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
			continue;


		strcpy( fullName, path );
		strcat( fullName, "\\" );
		strcat( fullName, ffd.cFileName );
		LoadLibrary( fullName );
	} while( FindNextFile( hFind, &ffd ) != 0 );


	FindClose(hFind);
}
