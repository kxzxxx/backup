extern char skip_exe1[512];
extern char skip_exe2[512];
extern char skip_exe3[512];
extern char skip_exe4[512];
extern char skip_exe5[512];
extern char skip_exe6[512];
extern char skip_exe7[512];
extern char skip_exe8[512];
extern char skip_exe9[512];





extern void ReadIni();
