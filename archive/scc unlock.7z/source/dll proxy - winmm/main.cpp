// Compiler: no intrinsics, no inline  (avoid unknown errors)


#include "windows.h"
#include <stdio.h>



//#define DEBUG_CALL


FILE *fp;
static CRITICAL_SECTION api_lock;


#include "DllLock.h"
#include "api.h"
#include "asi.h"
#include "Ini.h"




static DWORD WINAPI SafeStart( LPVOID param )
{
	Load_Asi( "scripts", "*.asi" );
	Load_Asi( "scripts_asi", "*.asi" );


	Load_Asi( "c:\\scripts", "*.asi" );
	Load_Asi( "c:\\scripts_asi", "*.asi" );
	
		
	return 0;
}




BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch(ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		// ignore thread creation messages
		DisableThreadLibraryCalls( hModule );
		InitializeCriticalSection( &api_lock );



		ReadIni();
		Reloc_Api();





		char name[1024];


		// exe blacklist
		GetModuleFileNameA( NULL, (LPCH) &name, 1024 );
		if( ( skip_exe1[0] == 0 ) || 
				( skip_exe1[0] && strstr( name, skip_exe1 ) != 0 ) ||
				( skip_exe2[0] && strstr( name, skip_exe2 ) != 0 ) ||
				( skip_exe3[0] && strstr( name, skip_exe3 ) != 0 ) ||
				( skip_exe4[0] && strstr( name, skip_exe4 ) != 0 ) ||
				( skip_exe5[0] && strstr( name, skip_exe5 ) != 0 ) ||
				( skip_exe6[0] && strstr( name, skip_exe6 ) != 0 ) ||
				( skip_exe7[0] && strstr( name, skip_exe7 ) != 0 ) ||
				( skip_exe8[0] && strstr( name, skip_exe8 ) != 0 ) ||
				( skip_exe9[0] && strstr( name, skip_exe9 ) != 0 ) )
		{
			// outside of DLL lock, do normal stuff
			DWORD threadId;
			HANDLE hSafeStart;


			hSafeStart = CreateThread( NULL, 0, SafeStart, 0, 0, &threadId );
			CloseHandle( hSafeStart );





			Load_Asi( "scripts", "*.boot" );
			Load_Asi( "scripts_asi", "*.boot" );

			Load_Asi( "c:\\scripts", "*.boot" );
			Load_Asi( "c:\\scripts_asi", "*.boot" );
		}
		break;



	case DLL_PROCESS_DETACH:
		LeaveCriticalSection( &api_lock );
		DeleteCriticalSection( &api_lock );
		break;
	};


	return TRUE;
}
