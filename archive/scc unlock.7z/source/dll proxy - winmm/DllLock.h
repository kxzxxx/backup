/*
Usage:


Declare at start of function:
DllLock lock( &gCS );
*/
	
		
class DllLock
{
	private:
		CRITICAL_SECTION *cs_;

	
	public:
		DllLock( CRITICAL_SECTION *cs );
		~DllLock();
};
