#ifndef _WeaponFiringCallbacks_H
#define _WeaponFiringCallbacks_H
#include "FB SDK/Frostbite_Classes.h"
namespace fb
{
	
	class WeaponFiringCallbacks
	{
		LPVOID vftable; // 0x00
	}; // 0x04

};

#endif