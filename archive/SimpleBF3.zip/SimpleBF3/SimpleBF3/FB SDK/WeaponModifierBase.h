#ifndef _WeaponModifierBase_H
#define _WeaponModifierBase_H
#include "FB SDK/Frostbite_Classes.h"
namespace fb
{
	class WeaponModifierBase
		: public DataContainer	// 0x00
	{
	}; // 0x08

};

#endif