#ifndef _PropertyWriter_H
#define _PropertyWriter_H
#include "Frostbite_Classes.h"
#include "PropertyWriterBase.h"
namespace fb
{
	class PropertyWriter
		:public PropertyWriterBase // Inherited class at offset 0x0
	{
		public:
	
	}; // fb::PropertyWriter<bool>

};

#endif