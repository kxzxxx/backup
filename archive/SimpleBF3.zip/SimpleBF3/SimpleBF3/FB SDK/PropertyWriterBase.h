#ifndef _PropertyWriterBase_H
#define _PropertyWriterBase_H
#include "Frostbite_Classes.h"
namespace fb
{
	class PropertyWriterBase // Inherited class at offset 0x0
	{
		public:
		CacheData * m_cache;                     // this+0x0

	}; // fb::PropertyWriterBase

};

#endif