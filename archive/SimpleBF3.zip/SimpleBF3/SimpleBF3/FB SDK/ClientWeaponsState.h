#ifndef _ClientWeaponsState_H
#define _ClientWeaponsState_H
#include "FB SDK/Frostbite_Classes.h"
#include "FB SDK/WeaponsState.h"
namespace fb
{
	
	class ClientWeaponsState
		: public WeaponsState	// 0x00
	{
	}; // 0xC4

};

#endif