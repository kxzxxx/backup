#ifndef _SpottingComponent_H
#define _SpottingComponent_H
#include "Frostbite_Classes.h"
namespace fb
{
		class SpottingComponent // Inherited class at offset 0x1C
	{
	public:
		SpottingComponentData & m_spottingData;                     // this+0x0
	}; // fb::SpottingComponent

};

#endif