#ifndef _AnimatedSoldierWeaponSpeedModule_H
#define _AnimatedSoldierWeaponSpeedModule_H
#include "FB SDK/Frostbite_Classes.h"
namespace fb
{
	
	class AnimatedSoldierWeaponSpeedModule
	{
	public:
		WeaponSpeedData* m_data;	// 0x00
	}; // 0x04

};

#endif