#ifndef _CtrRefBase_H
#define _CtrRefBase_H
#include "Frostbite_Classes.h"
namespace fb
{
	//template< typename T > 
	class CtrRefBase
	{
	public:
		DataContainer * m_ptr;                     // 0x0
	
		//T * m_ptr;                     // 0x0
	}; // fb::CtrRefBase

};

#endif