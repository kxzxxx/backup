#ifndef _ProjectileBlueprint_H
#define _ProjectileBlueprint_H
#include "Frostbite_Classes.h"
#include "ObjectBlueprint.h"
namespace fb
{
	class ProjectileBlueprint
		: public ObjectBlueprint	// 0x00
	{
	}; // 0x24
};

#endif