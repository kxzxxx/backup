#ifndef _NoCaseStringLess_H
#define _NoCaseStringLess_H
#include "FB SDK/Frostbite_Classes.h"
namespace fb
{
	
	class NoCaseStringLess
	{
	}; // fb::NoCaseStringLess

};

#endif