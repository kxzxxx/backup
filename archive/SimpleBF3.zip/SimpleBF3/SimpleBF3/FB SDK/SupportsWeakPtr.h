#ifndef _SupportsWeakPtr_H
#define _SupportsWeakPtr_H

//#include "../Frostbite_classes.h"

namespace fb
{

	
	class SupportsWeakPtr // Inherited class at offset 0x4
	{
	}; // fb::SupportsWeakPtr


};

#endif