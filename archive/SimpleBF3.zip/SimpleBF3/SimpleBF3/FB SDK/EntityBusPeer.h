#ifndef _EntityBusPeer_H
#define _EntityBusPeer_H
#include "Frostbite_Classes.h"
namespace fb
{
	class EntityBusPeer
		: public PropertyModificationListener		// 0x00
	{		//new
//			virtual class fb::EntityBus * getPeerBus();	// V: 0x1C
//			virtual const class fb::GameObjectData * getPeerData();	// V: 0x20
//			virtual void * __vecDelDtor(unsigned int);	// V: 0x24

	}; // 0x04
};

#endif