#ifndef _CriticalSection_H
#define _CriticalSection_H

//#include "../Frostbite_classes.h"

namespace fb
{

	class CriticalSection
    {
    public:
        unsigned char    m_data[0x20];
    };


};

#endif