#ifndef _Blueprint_H
#define _Blueprint_H
#include "EntityBusData.h"
namespace fb
{
	class Blueprint
		: public EntityBusData			// 0x00
	{
	}; // 0x20

};

#endif