#ifndef _MESSAGELISTENER_H
#define _MESSAGELISTENER_H
#include "FB SDK/Frostbite_Classes.h"
namespace fb
{
	class MessageListener
	{
	public:
		PAD(0x8);	// 0x00
	}; // 0x08

};

#endif