#ifndef _ConstWeakPtr_H
#define _ConstWeakPtr_H

namespace fb
{
	class ConstWeakPtr
	{
		public:
	};

};

#endif