#ifndef _FocusPoint_H
#define _FocusPoint_H
#include "Frostbite_Classes.h"
namespace fb
{
	class FocusPoint
	{

		TeamId team;                     // this+0x0
		/*WeakPtr<fb::ClientMapMarkerEntity>*/void* m_mapMarkerEntity;                     // this+0x4
						
	}; // FocusPoint

};

#endif