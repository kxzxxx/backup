#ifndef _EntryInput_H
#define _EntryInput_H
#include "EntryInputState.h"
namespace fb
{
	class EntryInput
		: public EntryInputState			// 0x00
	{
	}; // 0x2D4

};

#endif
