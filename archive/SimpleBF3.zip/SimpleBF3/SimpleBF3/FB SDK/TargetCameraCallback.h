#ifndef _TargetCameraCallback_H
#define _TargetCameraCallback_H
#include "Frostbite_Classes.h"
#include "ITypedObject.h"
namespace fb
{
	class TargetCameraCallback
		: public ITypedObject		// 0x00
	{
	}; // 0x04

};

#endif