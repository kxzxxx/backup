#ifndef _InputActionMapping_H
#define _InputActionMapping_H
#include "Frostbite_Classes.h"
namespace fb
{
	class InputActionMapping
	{
	public:
		eastl::vector<INT> m_mappedActions;		// 0x00
	}; // 0x10
};

#endif