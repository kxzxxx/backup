#ifndef _MovingBodyState_H
#define _MovingBodyState_H

namespace fb
{
	class MovingBodyState
	{
	public:
	
	}; // fb::MovingBodyState

};

#endif